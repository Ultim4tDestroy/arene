'use strict';
/* Dénicheur v2 : tableau de bord (HTML/CSS/JS pur, sans dépendance).
   Catégories : cartes & jeux, cryptos en temps réel (WebSocket), paris sportifs, suivi.
   Données gardées sur l'appareil (localStorage). Aucune clé ni donnée perso dans le code. */

const APP = 'denicheur';
const LS_MAIN = 'denicheur.v1';
const LS_KEY = 'denicheur.apikey';    // clé pokemontcg.io : jamais exportée
const LS_ODDS = 'denicheur.oddskey';  // clé The Odds API : jamais exportée
const LS_CACHE = 'denicheur.cache';   // dernières données reçues (mode hors ligne)

const DEFAULT_URLS = {
  pokemon: 'https://api.pokemontcg.io/v2',
  scryfall: 'https://api.scryfall.com',
  cheapshark: 'https://www.cheapshark.com/api/1.0',
  fx: 'https://api.frankfurter.dev/v1',
  odds: 'https://api.the-odds-api.com/v4',
  wsBinance: 'wss://stream.binance.com:9443',
  wsCoinbase: 'wss://ws-feed.exchange.coinbase.com',
  wsKraken: 'wss://ws.kraken.com/v2',
};
const URL_LABEL = { pokemon: 'Pokémon TCG', scryfall: 'Scryfall', cheapshark: 'CheapShark', fx: 'Taux de change', odds: 'The Odds API', wsBinance: 'Binance (WebSocket)', wsCoinbase: 'Coinbase (WebSocket)', wsKraken: 'Kraken (WebSocket)' };
const DOMAINS = { pokemon: 'Pokémon', magic: 'Magic', games: 'Jeux PC', other: 'Autre' };
const SRC_LABEL = { pokemon: 'Pokémon', magic: 'Magic', games: 'Jeux PC' };
const VIEWS = ['home', 'cards', 'crypto', 'bets', 'lab', 'track', 'settings'];
const COINS = [['BTC', 'Bitcoin'], ['ETH', 'Ethereum'], ['SOL', 'Solana'], ['ADA', 'Cardano'], ['DOGE', 'Dogecoin'], ['LINK', 'Chainlink'], ['LTC', 'Litecoin'], ['AVAX', 'Avalanche']];
const HOME_COINS = ['BTC', 'ETH', 'SOL', 'ADA', 'DOGE'];
const EXCH = { binance: 'Binance', coinbase: 'Coinbase', kraken: 'Kraken' };
const SPORTS = [
  ['soccer_france_ligue_one', 'Football : Ligue 1'], ['soccer_epl', 'Football : Premier League'], ['soccer_spain_la_liga', 'Football : Liga'],
  ['soccer_italy_serie_a', 'Football : Serie A'], ['soccer_germany_bundesliga', 'Football : Bundesliga'], ['soccer_uefa_champs_league', 'Football : Ligue des champions'],
  ['basketball_nba', 'Basket : NBA'], ['icehockey_nhl', 'Hockey : NHL'], ['americanfootball_nfl', 'Football US : NFL'], ['baseball_mlb', 'Baseball : MLB'],
];

/* ---------- Utilitaires ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const num = (v, min, max, def) => {
  if (typeof v === 'string') v = parseFloat(v.replace(/\s/g, '').replace(',', '.'));
  return typeof v === 'number' && Number.isFinite(v) ? clamp(v, min, max) : def;
};
const str = (v, max = 200) => typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max) : '';
const safeUrl = u => { u = str(u, 500); return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : ''; };
const cleanUrl = (u, ws) => {
  u = str(u, 200).replace(/\/+$/, '');
  const re = ws
    ? /^(wss:\/\/[^\s"'<>]+|ws:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/[^\s"'<>]*)?)$/i
    : /^(https:\/\/[^\s"'<>]+|http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/[^\s"'<>]*)?)$/i;
  return re.test(u) ? u : '';
};
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const nfs = {};
const money = (v, cur = 'EUR') => (nfs[cur] ||= new Intl.NumberFormat('fr-FR', { style: 'currency', currency: cur })).format(v);
const pxd = {};
const priceFmt = v => { const d = v >= 100 ? 2 : v >= 1 ? 3 : 5; return (pxd[d] ||= new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', minimumFractionDigits: d, maximumFractionDigits: d })).format(v); };
const pct = g => '−' + Math.round(g) + ' %';
const sp = (x, d = 2) => (x >= 0 ? '+' : '−') + Math.abs(x).toFixed(d).replace('.', ',') + ' %';
const fmtOdd = o => o.toFixed(2).replace('.', ',');
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const fmtDate = s => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? new Date(+m[1], +m[2] - 1, +m[3]).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }) : ''; };
const ago = ts => {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 45) return 'à l’instant';
  if (s < 3600) return `il y a ${Math.max(1, Math.round(s / 60))} min`;
  if (s < 86400) return `il y a ${Math.round(s / 3600)} h`;
  return `il y a ${Math.round(s / 86400)} j`;
};
const sec = ts => { const s = Math.max(0, Math.round((Date.now() - ts) / 1000)); return s < 2 ? 'à l’instant' : `il y a ${s} s`; };

/* ---------- État et validation ---------- */
const DEF = { demo: false, auto: true, interval: 5, minRef: 10, maxRef: 150, minGap: 15, minScore: 30, maxGamePrice: 40 };

function cleanSettings(r) {
  r = r && typeof r === 'object' ? r : {};
  const src = r.src && typeof r.src === 'object' ? r.src : {};
  const c = r.crypto && typeof r.crypto === 'object' ? r.crypto : {};
  const cex = c.ex && typeof c.ex === 'object' ? c.ex : {};
  const fees = c.fees && typeof c.fees === 'object' ? c.fees : {};
  const urls = {};
  for (const k in DEFAULT_URLS) urls[k] = cleanUrl(r.urls && r.urls[k], k.startsWith('ws')) || DEFAULT_URLS[k];
  const minRef = num(r.minRef, 1, 5000, DEF.minRef);
  return {
    demo: r.demo === true,
    auto: r.auto !== false,
    interval: [2, 5, 10, 30].includes(Number(r.interval)) ? Number(r.interval) : DEF.interval,
    src: { pokemon: src.pokemon !== false, magic: src.magic !== false, games: src.games !== false },
    minRef,
    maxRef: Math.max(minRef + 1, num(r.maxRef, 2, 20000, DEF.maxRef)),
    minGap: num(r.minGap, 5, 90, DEF.minGap),
    minScore: num(r.minScore, 0, 100, DEF.minScore),
    maxGamePrice: num(r.maxGamePrice, 1, 300, DEF.maxGamePrice),
    crypto: {
      live: c.live !== false,
      ex: { binance: cex.binance !== false, coinbase: cex.coinbase !== false, kraken: cex.kraken !== false },
      fees: { binance: num(fees.binance, 0, 5, 0.1), coinbase: num(fees.coinbase, 0, 5, 0.4), kraken: num(fees.kraken, 0, 5, 0.26) },
    },
    sport: SPORTS.some(s => s[0] === r.sport) ? r.sport : SPORTS[0][0],
    urls,
  };
}
function cleanTracker(a) {
  if (!Array.isArray(a)) return [];
  const out = [];
  for (const it of a.slice(0, 2000)) {
    if (!it || typeof it !== 'object') continue;
    const name = str(it.name, 120);
    if (!name) continue;
    const m0 = v => (v === null || v === undefined || v === '') ? null : num(v, 0, 1e7, null);
    const date = v => /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : '';
    out.push({
      id: str(it.id, 40) || uid(), name,
      domain: ['pokemon', 'magic', 'games', 'other'].includes(it.domain) ? it.domain : 'other',
      status: ['watch', 'stock', 'sold'].includes(it.status) ? it.status : 'watch',
      buy: m0(it.buy), qty: Math.round(num(it.qty, 1, 9999, 1)), sell: m0(it.sell), fees: m0(it.fees) ?? 0,
      buyDate: date(it.buyDate), sellDate: date(it.sellDate), note: str(it.note, 300), url: safeUrl(it.url),
      createdAt: num(it.createdAt, 0, 4e12, Date.now()),
    });
  }
  return out;
}
function cleanBets(a) {
  if (!Array.isArray(a)) return [];
  const out = [];
  for (const b of a.slice(0, 3000)) {
    if (!b || typeof b !== 'object') continue;
    const label = str(b.label, 120);
    const stake = num(b.stake, 0, 1e6, null), odds = num(b.odds, -1, 1e6, null);
    if (!label || stake === null || odds === null || odds < 1.01 || odds > 1000) continue;
    out.push({
      id: str(b.id, 40) || uid(), label, stake, odds,
      result: ['pending', 'won', 'lost', 'void'].includes(b.result) ? b.result : 'pending',
      date: /^\d{4}-\d{2}-\d{2}$/.test(b.date) ? b.date : '', note: str(b.note, 300), createdAt: num(b.createdAt, 0, 4e12, Date.now()),
    });
  }
  return out;
}
function cleanDecisions(o) {
  const out = {};
  if (!o || typeof o !== 'object' || Array.isArray(o)) return out;
  const entries = [];
  for (const k of Object.keys(o).slice(0, 5000)) {
    const v = o[k];
    if (!/^[a-z]{2}:[\w.\-%=+]{1,80}$/.test(k) || !Array.isArray(v)) continue;
    if (v[0] !== 'ok' && v[0] !== 'no') continue;
    entries.push([k, [v[0], num(v[1], 0, 4e12, Date.now())]]);
  }
  entries.sort((a, b) => b[1][1] - a[1][1]);
  for (const [k, v] of entries.slice(0, 1500)) out[k] = v;
  return out;
}
const fromData = d => {
  d = d && typeof d === 'object' ? d : {};
  return { onboarded: d.onboarded === true, settings: cleanSettings(d.settings), tracker: cleanTracker(d.tracker), bets: cleanBets(d.bets), decisions: cleanDecisions(d.decisions) };
};
const lsGet = k => { try { return localStorage.getItem(k); } catch { return null; } };

let S = (() => { try { return fromData(JSON.parse(lsGet(LS_MAIN))); } catch { return fromData(null); } })();
let apiKey = str(lsGet(LS_KEY) || '', 80);
let oddsKey = str(lsGet(LS_ODDS) || '', 80);
let cache = (() => { try { const c = JSON.parse(lsGet(LS_CACHE)); return c && typeof c === 'object' ? c : {}; } catch { return {}; } })();
let opps = [];
const ui = {
  view: 'home', domain: 'all', sort: 'score', q: '', treated: false, limit: 60, ttab: 'stock', btab: 'calc',
  loading: false, status: {}, fxNote: false, persist: null, lastDemo: 0,
  sbN: 2, calc: {}, odds: null, oddsLoading: false, oddsErr: '',
};

/* Sauvegarde différée + forcée en arrière-plan */
let saveTimer = 0;
function save() {
  clearTimeout(saveTimer); saveTimer = 0;
  try { localStorage.setItem(LS_MAIN, JSON.stringify(S)); }
  catch { toast('Impossible d’enregistrer : stockage plein ou bloqué.'); }
}
const scheduleSave = () => { clearTimeout(saveTimer); saveTimer = setTimeout(save, 600); };
function saveCache() { try { localStorage.setItem(LS_CACHE, JSON.stringify(cache)); } catch { /* cache facultatif */ } }
const flush = () => { if (saveTimer) save(); };
document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); else onVisible(); rtSync(); if (window.Lab) Lab.sync(); });
addEventListener('pagehide', flush);

async function askPersist() {
  try { if (navigator.storage && navigator.storage.persist) ui.persist = (await navigator.storage.persisted()) || (await navigator.storage.persist()); } catch { /* ignoré */ }
}

/* ---------- Décisions ---------- */
const decision = id => (S.decisions[id] || [])[0] || '';
function decide(id, v) { if (v) S.decisions[id] = [v, Date.now()]; else delete S.decisions[id]; scheduleSave(); }

/* ---------- Sources de données (cartes, jeux, change) ---------- */
async function getJSON(url, headers, wantHeaders) {
  if (navigator.onLine === false) throw new Error('offline');
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(url, { headers: { Accept: 'application/json', ...(headers || {}) }, signal: ctl.signal, cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer' });
    if (r.status === 429) throw new Error('rate');
    if (r.status === 401 || r.status === 403) throw new Error('auth');
    if (!r.ok) throw new Error('http ' + r.status);
    let data;
    try { data = await r.json(); } catch { throw new Error('badjson'); }
    return wantHeaders ? { data, headers: r.headers } : data;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('timeout');
    if (e instanceof TypeError) throw new Error('network');
    throw e;
  } finally { clearTimeout(t); }
}
function errMsg(e) {
  const m = (e && e.message) || '';
  if (m === 'offline') return 'hors ligne';
  if (m === 'timeout') return 'délai dépassé (15 s)';
  if (m === 'rate') return 'limite d’appels atteinte (429), réessaie plus tard';
  if (m === 'auth') return 'clé refusée par la source (401/403)';
  if (m.startsWith('http ')) return 'réponse ' + m.slice(5) + ' de la source';
  if (m === 'badjson') return 'réponse illisible';
  return 'source inaccessible (réseau, adresse ou blocage CORS)';
}
async function getFx() {
  const c = cache.fx;
  if (c && c.rate > 0 && Date.now() - c.at < 6 * 3600e3) { ui.fxNote = false; return c.rate; }
  try {
    const j = await getJSON(`${S.settings.urls.fx}/latest?base=USD&symbols=EUR`);
    const r = Number(j && j.rates && j.rates.EUR);
    if (r > 0.3 && r < 3) { cache.fx = { at: Date.now(), rate: r }; ui.fxNote = false; return r; }
  } catch { /* repli ci-dessous */ }
  ui.fxNote = true;
  return (c && c.rate) || 0.92;
}
const score100 = n => clamp(Math.round(n), 0, 100);

/* Pokémon : prix Cardmarket (EUR) et TCGplayer (USD) via pokemontcg.io */
function normPokemon(cards, fx) {
  const out = [];
  for (const c of Array.isArray(cards) ? cards : []) {
    const cm = c && c.cardmarket && c.cardmarket.prices;
    if (!cm) continue;
    const low = Number(cm.lowPrice), trend = Number(cm.trendPrice), avg30 = Number(cm.avg30);
    if (!(low > 0) || !(trend > 0) || low >= trend) continue;
    const gap = (trend - low) / trend * 100;
    let tcg = null;
    const tp = c.tcgplayer && c.tcgplayer.prices;
    if (tp) {
      const v = tp.holofoil || tp.normal || tp['1stEditionHolofoil'] || tp.unlimitedHolofoil || tp.reverseHolofoil || Object.values(tp)[0];
      if (v && Number(v.market) > 0) tcg = Number(v.market) * fx;
    }
    const spread = tcg ? (tcg - low) / tcg * 100 : null;
    const dip = avg30 > 0 && low < avg30 * 0.9;
    let sc = 2.2 * gap + (dip ? 10 : 0);
    if (spread !== null && spread >= 20) sc += Math.min(15, spread / 3);
    const parts = [`Prix bas ${money(low)} contre une tendance à ${money(trend)}`];
    if (dip) parts.push('sous la moyenne des 30 derniers jours');
    if (spread !== null && spread >= 20) parts.push(`TCGplayer ≈ ${money(tcg)}`);
    out.push({
      id: 'pk:' + str(c.id, 60).replace(/[^\w.\-]/g, '_'), domain: 'pokemon',
      title: str(c.name, 100), sub: [c.set && c.set.name, c.number, c.rarity].filter(Boolean).map(x => str(String(x), 60)).join(' · '),
      img: safeUrl(c.images && c.images.small), url: safeUrl(c.cardmarket.url),
      price: low, ref: trend, cur: 'EUR', gap, score: score100(sc), reason: parts.join(', ') + '.',
      caution: 'Le prix bas peut concerner un état joué ou une autre langue : vérifie la fiche avant d’acheter.',
    });
  }
  return out;
}
/* Magic : écart EUR / USD via Scryfall (prix mis à jour une fois par jour) */
function normMagic(cards, fx) {
  const out = [];
  for (const c of Array.isArray(cards) ? cards : []) {
    const p = c && c.prices;
    if (!p) continue;
    const usd = Number(p.usd), eur = Number(p.eur);
    if (!(usd > 0) || !(eur > 0)) continue;
    const usdE = usd * fx, buyEU = usdE > eur;
    const price = buyEU ? eur : usdE, ref = buyEU ? usdE : eur;
    const gap = (ref - price) / ref * 100;
    if (gap < 5) continue;
    const img = safeUrl((c.image_uris && c.image_uris.small) || (c.card_faces && c.card_faces[0] && c.card_faces[0].image_uris && c.card_faces[0].image_uris.small));
    out.push({
      id: 'sf:' + str(c.id, 60).replace(/[^\w.\-]/g, '_'), domain: 'magic',
      title: str(c.name, 100), sub: [c.set_name, c.rarity].filter(Boolean).map(x => str(String(x), 60)).join(' · '),
      img, url: safeUrl(c.scryfall_uri), price, ref, cur: 'EUR', gap, score: clamp(score100(gap * 1.3), 0, 70),
      reason: buyEU ? `Moins cher côté européen (${money(eur)}) que côté américain (≈ ${money(usdE)}).` : `Moins cher côté américain (≈ ${money(usdE)}) que côté européen (${money(eur)}).`,
      caution: 'Signal faible : prix du jour, hors frais, port et taxes. Score plafonné à 70.',
    });
  }
  return out;
}
/* Jeux PC : promotions CheapShark comparées au plus bas historique (USD) */
function normGames(deals, lows) {
  const out = [];
  for (const d of Array.isArray(deals) ? deals : []) {
    const price = Number(d.salePrice), ref = Number(d.normalPrice), sav = Number(d.savings), rating = Number(d.dealRating) || 0;
    if (!(price >= 0) || !(ref > price) || !(sav >= 10)) continue;
    const hist = lows && lows[d.gameID];
    const atLow = hist > 0 && price <= hist * 1.02;
    const bits = [`Prix normal ${money(ref, 'USD')}`];
    if (atLow) bits.push('au plus bas historique'); else if (hist > 0) bits.push(`plus bas connu ${money(hist, 'USD')}`);
    if (Number(d.steamRatingPercent) > 0) bits.push(`${Math.round(Number(d.steamRatingPercent))} % d’avis Steam positifs`);
    out.push({
      id: 'cs:' + str(String(d.gameID || d.dealID), 60).replace(/[^\w.\-]/g, '_'), domain: 'games',
      title: str(d.title, 100), sub: 'Achat pour toi, pas pour la revente',
      img: safeUrl(d.thumb), url: d.dealID ? safeUrl('https://www.cheapshark.com/redirect?dealID=' + encodeURIComponent(d.dealID)) : '',
      price, ref, cur: 'USD', gap: sav, score: score100(0.5 * sav + 3 * rating + (atLow ? 20 : 0)), reason: bits.join(', ') + '.',
      caution: 'Les clés de jeu se revendent mal : beaucoup de boutiques l’interdisent.',
    });
  }
  return out;
}
async function fetchPokemon(s) {
  const q = `cardmarket.prices.trendPrice:[${s.minRef} TO ${s.maxRef}]`;
  const url = `${s.urls.pokemon}/cards?q=${encodeURIComponent(q)}&orderBy=-cardmarket.prices.trendPrice&pageSize=250&select=id,name,number,rarity,set,images,cardmarket,tcgplayer`;
  const j = await getJSON(url, apiKey ? { 'X-Api-Key': apiKey } : null);
  if (!j || !Array.isArray(j.data)) throw new Error('badjson');
  return j.data;
}
async function fetchMagic(s) {
  const q = `game:paper eur>=${s.minRef} usd>=${s.minRef} eur<=${s.maxRef}`;
  const j = await getJSON(`${s.urls.scryfall}/cards/search?q=${encodeURIComponent(q)}&order=eur&dir=desc&unique=cards`);
  if (!j || !Array.isArray(j.data)) throw new Error('badjson');
  return j.data;
}
async function fetchGames(s) {
  const base = s.urls.cheapshark;
  const deals = await getJSON(`${base}/deals?onSale=1&pageSize=60&sortBy=${encodeURIComponent('Deal Rating')}&upperPrice=${Math.floor(s.maxGamePrice)}`);
  if (!Array.isArray(deals)) throw new Error('badjson');
  const lows = {};
  const ids = deals.slice(0, 25).map(d => d.gameID).filter(Boolean);
  if (ids.length) {
    try {
      const g = await getJSON(`${base}/games?ids=${ids.join(',')}`);
      for (const id of ids) { const p = Number(g && g[id] && g[id].cheapestPriceEver && g[id].cheapestPriceEver.price); if (p > 0) lows[id] = p; }
    } catch { /* facultatif */ }
  }
  return { deals, lows };
}

/* Données fictives (même forme que les API) pour le mode démo */
function demoOpps() {
  const fx = 0.92;
  const mk = (id, name, nb, rar, low, trend, avg30, tcg) => ({ id, name, number: nb, rarity: rar, set: { name: 'Démo · Série fictive' }, images: { small: '' }, cardmarket: { url: '', prices: { lowPrice: low, trendPrice: trend, avg30 } }, tcgplayer: { prices: { holofoil: { market: tcg } } } });
  const pk = [
    mk('demo-1', 'Dracaufeu (démo)', '4/102', 'Rare Holo', 38, 71, 66, 86), mk('demo-2', 'Mewtwo (démo)', '10/64', 'Rare Holo', 24.5, 31, 30, 40),
    mk('demo-3', 'Florizarre (démo)', '15/102', 'Rare Holo', 52, 64, 63, 60), mk('demo-4', 'Évoli (démo)', '51/64', 'Rare', 18, 33, 29, 41),
    mk('demo-5', 'Mew (démo)', '8/62', 'Ultra Rare', 61, 79, 82, 98), mk('demo-6', 'Lugia (démo)', '9/111', 'Rare Holo', 47, 56, 55, 52),
  ];
  const mg = (id, name, set, eur, usd) => ({ id, name, set_name: set, rarity: 'rare', scryfall_uri: '', prices: { usd: String(usd), eur: String(eur) }, image_uris: { small: '' } });
  const sf = [mg('demo-a', 'Ange du jugement (démo)', 'Démo · Extension', 14.2, 22.4), mg('demo-b', 'Orbe du chaos (démo)', 'Démo · Extension', 31, 33), mg('demo-c', 'Forêt ancienne (démo)', 'Démo · Core', 19.8, 15), mg('demo-d', 'Lame de cristal (démo)', 'Démo · Core', 11.5, 17.9), mg('demo-e', 'Sceau d’ombre (démo)', 'Démo · Extension', 42, 44)];
  const dl = (id, title, sale, normal, rating, rate) => ({ gameID: id, dealID: '', title, salePrice: String(sale), normalPrice: String(normal), savings: String(((normal - sale) / normal * 100).toFixed(3)), dealRating: String(rating), thumb: '', steamRatingPercent: String(rate) });
  const deals = [dl('d1', 'Jeu d’aventure (démo)', 7.99, 39.99, 9.4, 94), dl('d2', 'Stratégie spatiale (démo)', 12.49, 29.99, 8.8, 88), dl('d3', 'Roguelike sombre (démo)', 4.19, 19.99, 9.1, 91), dl('d4', 'Course arcade (démo)', 17.99, 24.99, 6.2, 72), dl('d5', 'Jeu de rôle (démo)', 14.99, 59.99, 9.6, 96), dl('d6', 'Puzzle zen (démo)', 2.99, 9.99, 8.1, 90), dl('d7', 'Simulation ferme (démo)', 9.99, 24.99, 7.7, 85)];
  return [...normPokemon(pk, fx), ...normMagic(sf, fx), ...normGames(deals, { d1: 7.99, d2: 10.99, d3: 3.99, d5: 14.99, d6: 2.5 })];
}

/* Orchestration du rafraîchissement (cartes et jeux) */
let refreshPromise = null;
const enabledSources = () => Object.keys(SRC_LABEL).filter(k => S.settings.src[k]);
const lastUpdate = () => S.settings.demo ? ui.lastDemo : Math.max(0, ...enabledSources().map(k => (cache[k] && cache[k].at) || 0));
function rebuildOpps() {
  if (S.settings.demo) { opps = demoOpps(); return; }
  opps = enabledSources().flatMap(k => (cache[k] && Array.isArray(cache[k].items)) ? cache[k].items : []);
}
function refreshAll() {
  if (refreshPromise) return refreshPromise;
  refreshPromise = (async () => {
    ui.loading = true; renderLoading();
    const s = S.settings;
    if (s.demo) {
      ui.lastDemo = Date.now();
      for (const k of Object.keys(SRC_LABEL)) ui.status[k] = { state: 'demo', at: ui.lastDemo };
    } else {
      const active = enabledSources();
      for (const k of Object.keys(SRC_LABEL)) ui.status[k] = { state: active.includes(k) ? 'loading' : 'off' };
      renderSrcs();
      if (active.length) {
        const fx = (active.includes('pokemon') || active.includes('magic')) ? await getFx() : 0.92;
        const jobs = {
          pokemon: async () => normPokemon(await fetchPokemon(s), fx),
          magic: async () => normMagic(await fetchMagic(s), fx),
          games: async () => { const r = await fetchGames(s); return normGames(r.deals, r.lows); },
        };
        const res = await Promise.allSettled(active.map(k => jobs[k]()));
        res.forEach((r, i) => {
          const k = active[i];
          if (r.status === 'fulfilled') { cache[k] = { at: Date.now(), items: r.value.filter(o => o.score >= 5).slice(0, 400) }; ui.status[k] = { state: 'ok', at: cache[k].at }; }
          else ui.status[k] = { state: 'err', msg: errMsg(r.reason), at: (cache[k] && cache[k].at) || 0 };
        });
        saveCache();
      }
    }
    rebuildOpps();
  })().catch(() => { /* rien ne doit bloquer l'interface */ }).finally(() => {
    ui.loading = false; refreshPromise = null; renderLoading(); renderData();
  });
  return refreshPromise;
}
let refreshDebounce = 0;
const scheduleRefresh = () => { clearTimeout(refreshDebounce); refreshDebounce = setTimeout(() => { if (S.onboarded) { rebuildOpps(); renderData(); refreshAll(); } }, 700); };
function onVisible() {
  if (!S.onboarded) return;
  renderLive();
  if (S.settings.auto && !ui.loading && Date.now() - lastUpdate() > S.settings.interval * 60000) refreshAll();
}
setInterval(() => {
  if (!S.onboarded || document.hidden) return;
  renderLive();
  if (S.settings.auto && !ui.loading && Date.now() - lastUpdate() >= S.settings.interval * 60000) refreshAll();
}, 30000);

/* =====================================================================
   Cryptos en temps réel : WebSocket Binance, Coinbase, Kraken (paires en EUR)
   ===================================================================== */
const RT = { ws: {}, tick: {}, hist: {}, status: {}, retry: {}, timers: {}, last: {}, running: false, loop: 0, demo: 0, stopTimer: 0, regs: {}, chipHtml: '', demoBase: null };
const rtOn = () => S.settings.crypto.live;
const rtActive = () => S.onboarded && !document.hidden && (ui.view === 'home' || ui.view === 'crypto') && rtOn();

function rtSync() {
  if (rtActive()) { clearTimeout(RT.stopTimer); RT.stopTimer = 0; rtStart(); }
  else if (RT.running && !RT.stopTimer) RT.stopTimer = setTimeout(() => { RT.stopTimer = 0; if (!rtActive()) rtStop(); }, 8000);
}
function rtStart() {
  if (RT.running) return;
  RT.running = true;
  if (S.settings.demo) startDemoTicks();
  else for (const ex of Object.keys(EXCH)) if (S.settings.crypto.ex[ex]) connect(ex);
  RT.loop = setInterval(rtRender, 500);
  rtRender();
}
function rtStop() {
  RT.running = false;
  clearInterval(RT.loop); clearInterval(RT.demo); RT.loop = 0; RT.demo = 0;
  for (const ex of Object.keys(RT.timers)) clearTimeout(RT.timers[ex]);
  RT.timers = {};
  for (const ex of Object.keys(RT.ws)) { try { RT.ws[ex].close(); } catch { /* ignoré */ } }
  RT.ws = {}; RT.status = {}; RT.retry = {};
  renderRtStatus();
}
function rtRestart() { rtStop(); RT.tick = {}; RT.hist = {}; rtSync(); }
function setStatus(ex, state, msg) { RT.status[ex] = { state, msg: msg || '' }; }

function connect(ex) {
  if (RT.ws[ex]) return;
  const u = S.settings.urls;
  const url = ex === 'binance' ? `${u.wsBinance}/stream?streams=${COINS.map(([c]) => c.toLowerCase() + 'eur@ticker').join('/')}` : ex === 'coinbase' ? u.wsCoinbase : u.wsKraken;
  setStatus(ex, 'connecting');
  let ws;
  try { ws = new WebSocket(url); } catch { setStatus(ex, 'err', 'adresse invalide'); return; }
  RT.ws[ex] = ws;
  ws.onopen = () => {
    setStatus(ex, 'ok'); RT.retry[ex] = 0; RT.last[ex] = Date.now();
    try {
      if (ex === 'coinbase') for (const [c] of COINS) ws.send(JSON.stringify({ type: 'subscribe', product_ids: [c + '-EUR'], channels: ['ticker'] }));
      if (ex === 'kraken') for (const [c] of COINS) ws.send(JSON.stringify({ method: 'subscribe', params: { channel: 'ticker', symbol: [c + '/EUR'] } }));
    } catch { /* ignoré */ }
  };
  ws.onmessage = e => { RT.last[ex] = Date.now(); try { parseMsg(ex, JSON.parse(e.data)); } catch { /* message ignoré */ } };
  ws.onerror = () => { /* le détail est dans onclose */ };
  ws.onclose = () => {
    if (RT.ws[ex] === ws) delete RT.ws[ex];
    if (!RT.running) return;
    setStatus(ex, 'err', navigator.onLine === false ? 'hors ligne' : 'connexion perdue, nouvelle tentative…');
    const n = RT.retry[ex] = (RT.retry[ex] || 0) + 1;
    RT.timers[ex] = setTimeout(() => { if (RT.running && S.settings.crypto.ex[ex]) connect(ex); }, Math.min(30000, 1000 * 2 ** Math.min(n, 5)));
  };
}
function parseMsg(ex, j) {
  if (!j || typeof j !== 'object') return;
  if (ex === 'binance') {
    const m = j.data || j;
    if (!m || typeof m.s !== 'string' || !m.s.endsWith('EUR')) return;
    setTick(m.s.slice(0, -3), 'binance', { bid: +m.b, ask: +m.a, last: +m.c, chg: m.P !== undefined ? +m.P : null });
  } else if (ex === 'coinbase') {
    if (j.type !== 'ticker' || typeof j.product_id !== 'string') return;
    const o = +j.open_24h, p = +j.price;
    setTick(j.product_id.split('-')[0], 'coinbase', { bid: +j.best_bid, ask: +j.best_ask, last: p, chg: o > 0 ? (p / o - 1) * 100 : null });
  } else if (ex === 'kraken') {
    if (j.channel !== 'ticker' || !Array.isArray(j.data)) return;
    for (const d of j.data) if (d && typeof d.symbol === 'string') setTick(d.symbol.split('/')[0], 'kraken', { bid: +d.bid, ask: +d.ask, last: +d.last, chg: d.change_pct !== undefined ? +d.change_pct : null });
  }
}
function setTick(coin, ex, t) {
  if (!COINS.some(c => c[0] === coin)) return;
  if (!(t.last > 0)) return;
  const bid = t.bid > 0 ? t.bid : t.last, ask = t.ask > 0 ? t.ask : t.last;
  (RT.tick[coin] ||= {})[ex] = { bid, ask, last: t.last, chg: Number.isFinite(t.chg) ? t.chg : null, t: Date.now() };
  const h = (RT.hist[coin] ||= []), now = Date.now();
  if (!h.length || now - h[h.length - 1][0] >= 1500) { h.push([now, t.last]); if (h.length > 150) h.shift(); }
}
/* Mode démo : prix simulés (marche aléatoire), clairement signalés comme fictifs */
function startDemoTicks() {
  RT.demoBase = { BTC: 61000, ETH: 2400, SOL: 150, ADA: 0.45, DOGE: 0.12, LINK: 14, LTC: 70, AVAX: 28 };
  const chg = { BTC: 1.2, ETH: -0.6, SOL: 3.1, ADA: -1.4, DOGE: 0.4, LINK: 2.2, LTC: -0.2, AVAX: 1.7 };
  const step = () => {
    for (const [c] of COINS) {
      RT.demoBase[c] *= 1 + (Math.random() - 0.5) * 0.0012;
      for (const ex of Object.keys(EXCH)) {
        if (!S.settings.crypto.ex[ex]) continue;
        const mid = RT.demoBase[c] * (1 + (Math.random() - 0.5) * 0.0016), half = mid * 0.0003;
        setTick(c, ex, { bid: mid - half, ask: mid + half, last: mid, chg: chg[c] + (Math.random() - 0.5) * 0.1 });
        RT.last[ex] = Date.now();
        setStatus(ex, 'ok');
      }
    }
  };
  step();
  RT.demo = setInterval(step, 800);
}
/* Statistiques d'un actif : meilleurs prix, écart brut et net entre bourses différentes */
function coinStats(c) {
  const T = RT.tick[c] || {}, now = Date.now(), fe = S.settings.crypto.fees;
  const fresh = {};
  for (const ex of Object.keys(T)) if (S.settings.crypto.ex[ex] && now - T[ex].t < 20000) fresh[ex] = T[ex];
  const exs = Object.keys(fresh);
  if (!exs.length) return null;
  const price = exs.reduce((a, ex) => a + fresh[ex].last, 0) / exs.length;
  let chg = null;
  for (const ex of ['binance', 'kraken', 'coinbase']) if (fresh[ex] && fresh[ex].chg !== null) { chg = fresh[ex].chg; break; }
  let best = null;
  for (const a of exs) for (const b of exs) {
    if (a === b) continue;
    const gross = (fresh[b].bid - fresh[a].ask) / fresh[a].ask * 100;
    const net = gross - fe[a] - fe[b];
    if (!best || net > best.net) best = { gross, net, buy: a, sell: b };
  }
  return { fresh, price, chg, ...(best || { gross: null, net: null, buy: null, sell: null }) };
}
function bestNet() {
  let best = null;
  for (const [c] of COINS) { const st = coinStats(c); if (st && st.net !== null && (!best || st.net > best.net)) best = { c, ...st }; }
  return best;
}

/* Tableau crypto : construit une fois, puis mis à jour cellule par cellule (pas de reconstruction) */
function buildCrypto(id, { coins, compact }) {
  const el = $('#' + id);
  if (!el) return;
  const exs = Object.keys(EXCH);
  const head = compact ? '' : `<div class="crow head" role="row"><div class="c-name">Actif</div><div class="c-price">Prix</div><div class="c-chg">24 h</div>${exs.map((e, i) => `<div class="c-ex e${i + 1}">${EXCH[e]}</div>`).join('')}<div class="c-net">Écart net</div><div class="c-spark">Tendance</div></div>`;
  const rows = COINS.filter(([c]) => coins.includes(c)).map(([c, n]) =>
    `<div class="crow" data-c="${c}" role="row"><div class="c-name"><b>${c}</b><span>${n}</span></div><div class="c-price"><span class="flash" data-f="price">—</span></div><div class="c-chg" data-f="chg">—</div>${exs.map((e, i) => `<div class="c-ex e${i + 1} off" data-ex="${e}">—</div>`).join('')}<div class="c-net"><span class="net-l">Écart net théorique : </span><span data-f="netv">—</span><span class="net-d" data-f="netd"></span></div><div class="c-spark"><svg class="spark" viewBox="0 0 100 28" preserveAspectRatio="none" aria-hidden="true"><polyline data-f="spark" points=""/></svg></div></div>`).join('');
  el.innerHTML = `<div class="ctable ${compact ? 'compact' : ''}" role="table">${head}${rows}</div>`;
  RT.regs[id] = {
    el,
    rows: $$('.crow[data-c]', el).map(r => ({
      c: r.dataset.c, price: $('[data-f=price]', r), chg: $('[data-f=chg]', r), netv: $('[data-f=netv]', r), netd: $('[data-f=netd]', r),
      poly: $('[data-f=spark]', r), svg: $('.spark', r), ex: Object.fromEntries(exs.map(e => [e, $(`[data-ex=${e}]`, r)])), lp: 0, sp: 0,
    })),
  };
  updateCrypto(RT.regs[id]);
}
const setText = (el, t) => { if (el.textContent !== t) el.textContent = t; };
function updateCrypto(reg) {
  if (!reg.el.isConnected || reg.el.offsetParent === null) return;
  for (const r of reg.rows) {
    const st = coinStats(r.c);
    if (!st) {
      setText(r.price, '—'); setText(r.chg, '—'); setText(r.netv, '—'); setText(r.netd, '');
      for (const ex in r.ex) { setText(r.ex[ex], '—'); r.ex[ex].classList.add('off'); }
      continue;
    }
    setText(r.price, priceFmt(st.price));
    if (r.lp && st.price !== r.lp) { const cls = st.price > r.lp ? 'up' : 'down'; r.price.classList.remove('up', 'down'); void r.price.offsetWidth; r.price.classList.add(cls); }
    r.lp = st.price;
    if (st.chg !== null) { setText(r.chg, sp(st.chg)); r.chg.className = 'c-chg ' + (st.chg >= 0 ? 'pos' : 'neg'); } else setText(r.chg, '—');
    for (const ex in r.ex) {
      const t = st.fresh[ex];
      setText(r.ex[ex], t ? priceFmt(t.last) : '—');
      r.ex[ex].classList.toggle('off', !t);
    }
    if (st.net !== null) {
      setText(r.netv, sp(st.net)); r.netv.className = st.net > 0 ? 'net-pos' : 'net-neg';
      setText(r.netd, ` (${EXCH[st.buy]} → ${EXCH[st.sell]}, brut ${sp(st.gross)})`);
    } else { setText(r.netv, '—'); setText(r.netd, ''); }
    const now = Date.now();
    if (now - r.sp > 1500) {
      r.sp = now;
      const h = RT.hist[r.c];
      if (h && h.length > 2) {
        let lo = Infinity, hi = -Infinity;
        for (const p of h) { if (p[1] < lo) lo = p[1]; if (p[1] > hi) hi = p[1]; }
        const span = hi - lo || 1;
        r.poly.setAttribute('points', h.map((p, i) => `${(i / (h.length - 1) * 100).toFixed(1)},${(26 - (p[1] - lo) / span * 24).toFixed(1)}`).join(' '));
        r.svg.setAttribute('class', 'spark ' + (h[h.length - 1][1] >= h[0][1] ? 'up' : 'down'));
      }
    }
  }
}
function renderRtStatus() {
  const exs = Object.keys(EXCH).filter(e => S.settings.crypto.ex[e]);
  const live = rtOn();
  let html = '', ok = 0;
  for (const e of exs) {
    const st = RT.status[e] || { state: live ? 'idle' : 'off' };
    let cls = '', txt = 'en attente';
    if (!live) { txt = 'en pause'; }
    else if (st.state === 'ok') { cls = 'ok'; ok++; txt = S.settings.demo ? 'démo' : 'en direct' + (RT.last[e] ? ' · ' + sec(RT.last[e]) : ''); }
    else if (st.state === 'connecting') { cls = 'warn pulse'; txt = 'connexion…'; }
    else if (st.state === 'err') { cls = 'err'; txt = st.msg || 'erreur'; }
    html += `<span class="src"><span class="dot ${cls}"></span><b>${EXCH[e]}</b> ${esc(txt)}</span>`;
  }
  if (!exs.length) html = '<span class="src">Aucune bourse activée (Réglages)</span>';
  if (html !== RT.chipHtml) { RT.chipHtml = html; const el = $('#rt-status'); if (el) el.innerHTML = html; }
  const pill = !live ? 'Pause' : S.settings.demo ? 'Démo' : `${ok}/${exs.length} bourses en direct`;
  $$('[data-rtpill]').forEach(p => { const h = `<span class="dot ${ok ? 'ok pulse' : 'err'}"></span>${esc(pill)}`; if (p.dataset.h !== h) { p.innerHTML = h; p.dataset.h = h; } });
}
function rtRender() {
  if (document.hidden) return;
  const now = Date.now();
  for (const ex of Object.keys(RT.ws)) if (RT.ws[ex].readyState === 1 && RT.last[ex] && now - RT.last[ex] > 30000) { try { RT.ws[ex].close(); } catch { /* ignoré */ } }
  for (const reg of Object.values(RT.regs)) updateCrypto(reg);
  renderRtStatus();
  const k = $('#k-net');
  if (k) {
    const b = bestNet();
    setText($('.k-v', k), b ? sp(b.net) : '—');
    $('.k-v', k).className = 'k-v ' + (b && b.net > 0 ? 'pos' : '');
    setText($('.k-s', k), b ? `${b.c} · ${EXCH[b.buy]} → ${EXCH[b.sell]}, après frais` : 'en attente de données');
  }
}

/* =====================================================================
   Paris sportifs : calculs, scanner de cotes (clé optionnelle), carnet
   ===================================================================== */
function analyzeOdds(events) {
  const out = [];
  for (const ev of Array.isArray(events) ? events : []) {
    const best = {};
    for (const b of Array.isArray(ev.bookmakers) ? ev.bookmakers : []) {
      const m = (b.markets || []).find(x => x.key === 'h2h');
      if (!m) continue;
      for (const o of m.outcomes || []) {
        const p = Number(o.price), nm = str(String(o.name), 60);
        if (!(p > 1) || !nm) continue;
        if (!best[nm] || p > best[nm].price) best[nm] = { price: p, book: str(String(b.title || b.key), 40) };
      }
    }
    const names = Object.keys(best);
    if (names.length < 2 || names.length > 3) continue;
    const inv = names.reduce((a, n) => a + 1 / best[n].price, 0);
    out.push({ id: str(String(ev.id || ''), 40), title: `${str(String(ev.home_team || '?'), 60)} – ${str(String(ev.away_team || '?'), 60)}`, start: str(String(ev.commence_time || ''), 30), best, names, inv, margin: (1 - inv) * 100, nBooks: (ev.bookmakers || []).length });
  }
  return out.sort((a, b) => b.margin - a.margin);
}
async function scanOdds() {
  if (S.settings.demo) {
    const mk = (id, h, a, o) => ({ id, home_team: h, away_team: a, commence_time: '', bookmakers: o.map((p, i) => ({ key: 'b' + i, title: 'Bookmaker ' + 'ABC'[i], markets: [{ key: 'h2h', outcomes: [{ name: h, price: p[0] }, { name: 'Nul', price: p[1] }, { name: a, price: p[2] }] }] })) });
    ui.odds = { at: Date.now(), demo: true, remaining: null, events: analyzeOdds([mk('d1', 'Équipe A (démo)', 'Équipe B (démo)', [[2.1, 3.3, 3.6], [1.9, 3.6, 4.1], [2.0, 3.2, 3.5]]), mk('d2', 'Équipe C (démo)', 'Équipe D (démo)', [[2.5, 3.1, 2.9], [2.3, 3.4, 3.4], [2.6, 3.0, 2.8]])]) };
    ui.oddsErr = ''; renderBets(); return;
  }
  if (!oddsKey) { toast('Ajoute ta clé The Odds API dans les Réglages.'); return; }
  ui.oddsLoading = true; ui.oddsErr = ''; renderBets();
  try {
    const url = `${S.settings.urls.odds}/sports/${encodeURIComponent(S.settings.sport)}/odds/?apiKey=${encodeURIComponent(oddsKey)}&regions=eu&markets=h2h&oddsFormat=decimal`;
    const { data, headers } = await getJSON(url, null, true);
    const rem = headers.get('x-requests-remaining');
    ui.odds = { at: Date.now(), demo: false, remaining: rem !== null ? Number(rem) : null, events: analyzeOdds(data) };
  } catch (e) { ui.oddsErr = errMsg(e); }
  ui.oddsLoading = false; renderBets();
}
const betProfit = b => b.result === 'won' ? b.stake * (b.odds - 1) : b.result === 'lost' ? -b.stake : 0;
function betStats() {
  let staked = 0, net = 0, won = 0, settled = 0;
  for (const b of S.bets) if (b.result === 'won' || b.result === 'lost') { staked += b.stake; net += betProfit(b); settled++; if (b.result === 'won') won++; }
  return { staked, net, roi: staked > 0 ? net / staked * 100 : null, settled, won, pending: S.bets.filter(b => b.result === 'pending').length };
}
function calcSure() {
  const out = $('#sb-out'); if (!out) return;
  const n = ui.sbN, odds = [1, 2, 3].slice(0, n).map(i => num($('#sb-o' + i).value, 1.01, 1000, null)), stake = num($('#sb-stake').value, 1, 1e7, null);
  if (odds.some(o => o === null) || stake === null) { out.textContent = 'Renseigne les cotes (décimales, supérieures à 1) et la mise.'; return; }
  const inv = odds.reduce((a, o) => a + 1 / o, 0), ret = stake / inv, profit = ret - stake, p = profit / stake * 100;
  const lines = odds.map((o, i) => { const s = stake * (1 / o) / inv; return `<div>Issue ${i + 1} : miser <b>${money(s)}</b> à la cote ${fmtOdd(o)}, retour ${money(s * o)}</div>`; }).join('');
  const head = inv < 1 ? `<div class="pos"><b>Arbitrage : gain garanti de ${money(profit)} (${p.toFixed(2).replace('.', ',')} %)</b></div>` : `<div class="neg"><b>Pas d’arbitrage : tu perds ${money(-profit)} (${Math.abs(p).toFixed(2).replace('.', ',')} %) quel que soit le résultat.</b></div>`;
  out.innerHTML = head + lines + `<div class="muted small">Somme des probabilités implicites : ${(inv * 100).toFixed(2).replace('.', ',')} %. Vérifie que les cotes sont toujours disponibles avant de miser.</div>`;
}
function calcEv() {
  const out = $('#ev-out'); if (!out) return;
  const o = num($('#ev-odds').value, 1.01, 1000, null), p = num($('#ev-p').value, 0.01, 99.99, null);
  if (o === null || p === null) { out.textContent = 'Renseigne la cote et ta probabilité estimée.'; return; }
  const ev = p / 100 * o - 1, imp = 100 / o;
  out.innerHTML = `<div class="${ev >= 0 ? 'pos' : 'neg'}"><b>Valeur attendue : ${sp(ev * 100)} par euro misé</b></div><div>Probabilité implicite de la cote : ${imp.toFixed(1).replace('.', ',')} %. Ton estimation : ${p.toFixed(1).replace('.', ',')} %.</div><div class="muted small">Le résultat vaut ce que vaut ton estimation : une cote n’est « value » que si ta probabilité est plus juste que celle du bookmaker.</div>`;
}

/* ---------- Rendu : en-têtes communs ---------- */
function renderLoading() {
  $$('[data-refresh]').forEach(b => { b.classList.toggle('spin', ui.loading); b.disabled = ui.loading; });
  renderLive();
}
function renderLive() {
  let html;
  if (ui.loading) html = '<span class="dot pulse ok"></span>Actualisation en cours…';
  else if (S.settings.demo) html = '<span class="dot ok"></span>Mode démo : données fictives';
  else {
    const at = lastUpdate();
    if (!at) html = '<span class="dot"></span>Aucune donnée reçue pour l’instant';
    else {
      const next = S.settings.auto ? Math.max(0, Math.ceil((at + S.settings.interval * 60000 - Date.now()) / 60000)) : null;
      html = `<span class="dot ok ${S.settings.auto ? 'pulse' : ''}"></span>Cartes et jeux actualisés ${esc(ago(at))}` + (next !== null ? ` · prochaine mise à jour dans ${next <= 0 ? 'moins d’1' : next} min` : ' · mise à jour automatique désactivée');
    }
  }
  $$('[data-live]').forEach(el => { if (el.dataset.h !== html) { el.innerHTML = html; el.dataset.h = html; } });
}
function renderBanner() {
  const errs = Object.entries(ui.status).filter(([, v]) => v.state === 'err');
  const offline = navigator.onLine === false;
  let html = '', cls = 'banner';
  if (offline) html = 'Tu es hors ligne : les dernières données reçues restent affichées. L’actualisation reprendra dès le retour du réseau.';
  else if (errs.length || ui.fxNote) {
    const li = errs.map(([k, v]) => `<li><b>${esc(SRC_LABEL[k])}</b> : ${esc(v.msg)}${v.at ? ` (dernières données ${esc(ago(v.at))})` : ''}</li>`).join('');
    html = (errs.length ? 'Certaines sources n’ont pas répondu :<ul>' + li + '</ul>' : '') + (ui.fxNote ? '<div>Taux de change indisponible : taux indicatif utilisé.</div>' : '');
    if (errs.length) cls += ' err';
  }
  $$('[data-banner]').forEach(el => { el.hidden = !html; if (html) { el.className = cls; el.setAttribute('data-banner', ''); el.innerHTML = html; } });
}
const kpiHTML = (l, v, s, cls = '', id = '') => `<div class="kpi"${id ? ` id="${id}"` : ''}><div class="k-l">${l}</div><div class="k-v ${cls}">${v}</div><div class="k-s">${s}</div></div>`;

/* ---------- Rendu : opportunités (cartes & jeux) ---------- */
function visibleOpps(domain = ui.domain) {
  const s = S.settings, q = ui.q.trim().toLowerCase();
  const list = opps.filter(o => (domain === 'all' || o.domain === domain) && o.score >= s.minScore && o.gap >= s.minGap && (!q || (o.title + ' ' + o.sub).toLowerCase().includes(q)) && (ui.treated || !decision(o.id)));
  const by = { score: (a, b) => b.score - a.score || b.gap - a.gap, gap: (a, b) => b.gap - a.gap, 'price-asc': (a, b) => a.price - b.price, 'price-desc': (a, b) => b.price - a.price }[ui.sort] || ((a, b) => b.score - a.score);
  return list.sort(by);
}
function thumbHTML(o, mini) {
  return `<div class="thumb ${mini ? 'mini' : o.domain === 'games' ? 'wide' : ''}"><span aria-hidden="true">${esc((o.title[0] || '?').toUpperCase())}</span>${o.img ? `<img src="${esc(o.img)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer">` : ''}</div>`;
}
function cardHTML(o) {
  const d = decision(o.id), sc = o.score >= 70 ? 'hi' : o.score >= 45 ? 'mid' : '';
  const view = o.url ? `<a class="btn" href="${esc(o.url)}" target="_blank" rel="noopener noreferrer"><svg class="ic" aria-hidden="true"><use href="#i-ext"/></svg>Voir</a>` : '';
  const acts = d
    ? `<div class="actions two">${view}<button class="btn" data-act="undo-decision" data-id="${esc(o.id)}"><svg class="ic" aria-hidden="true"><use href="#i-undo"/></svg>Annuler</button></div>`
    : `<div class="actions ${o.url ? '' : 'two'}">${view}<button class="btn" data-act="ignore" data-id="${esc(o.id)}" aria-label="Ignorer ${esc(o.title)}"><svg class="ic" aria-hidden="true"><use href="#i-x"/></svg>Ignorer</button><button class="btn primary" data-act="validate" data-id="${esc(o.id)}" aria-label="Valider ${esc(o.title)}"><svg class="ic" aria-hidden="true"><use href="#i-check"/></svg>Valider</button></div>`;
  return `<article class="card ${d ? 'treated' : ''}" data-id="${esc(o.id)}">${thumbHTML(o)}
    <div class="cbody">
      <div class="chead"><span class="badge dom-${o.domain}">${esc(DOMAINS[o.domain])}</span><span class="score ${sc}" title="Score de 0 à 100">Score ${o.score}</span></div>
      <h3 class="ctitle">${esc(o.title)}</h3>
      <p class="csub">${esc(o.sub)}${d ? ` · <span class="tag-done ${d === 'ok' ? 'pos' : ''}">${d === 'ok' ? 'Validée' : 'Ignorée'}</span>` : ''}</p>
      <div class="prices"><div><span class="p-l">Prix</span><strong>${money(o.price, o.cur)}</strong></div><div><span class="p-l">Référence</span><span class="ref">${money(o.ref, o.cur)}</span></div><span class="gap">${pct(o.gap)}</span></div>
      <p class="reason">${esc(o.reason)}</p>
      <p class="caution">${esc(o.caution)}</p>
    </div>${acts}</article>`;
}
function rowHTML(o) {
  return `<div class="orow" data-id="${esc(o.id)}">${thumbHTML(o, true)}
    <div class="o-main"><div class="o-t">${esc(o.title)}</div><div class="o-s"><span class="badge dom-${o.domain}">${esc(DOMAINS[o.domain])}</span> Score ${o.score}</div></div>
    <div class="o-n"><strong>${money(o.price, o.cur)}</strong><span class="gap">${pct(o.gap)}</span></div>
    <div class="o-act"><button class="btn" data-act="ignore" data-id="${esc(o.id)}" aria-label="Ignorer ${esc(o.title)}"><svg class="ic" aria-hidden="true"><use href="#i-x"/></svg>Ignorer</button><button class="btn primary" data-act="validate" data-id="${esc(o.id)}" aria-label="Valider ${esc(o.title)}"><svg class="ic" aria-hidden="true"><use href="#i-check"/></svg>Valider</button></div></div>`;
}
function emptyOpps() {
  let t, d;
  if (!enabledSources().length && !S.settings.demo) { t = 'Aucune source active'; d = 'Active au moins une source dans les Réglages.'; }
  else if (!opps.length) { t = 'Aucune donnée pour l’instant'; d = Object.values(ui.status).some(v => v.state === 'err') ? 'Les sources n’ont pas répondu. Vérifie ta connexion, puis appuie sur Actualiser.' : 'Appuie sur Actualiser pour lancer la première analyse.'; }
  else { t = 'Aucune opportunité ne passe tes seuils'; d = 'Baisse l’écart minimum ou le score minimum dans les Réglages.'; }
  return `<div class="empty"><strong>${t}</strong>${d}</div>`;
}
function renderSrcs() {
  const label = { ok: 'OK', err: 'erreur', loading: 'chargement', off: 'désactivée', demo: 'démo' };
  const el = $('#srcs'); if (!el) return;
  el.innerHTML = Object.keys(SRC_LABEL).map(k => {
    const v = ui.status[k] || { state: S.settings.src[k] ? 'idle' : 'off' };
    const cls = v.state === 'ok' || v.state === 'demo' ? 'ok' : v.state === 'err' ? 'err' : '';
    return `<span class="src"><span class="dot ${cls}"></span><b>${esc(SRC_LABEL[k])}</b> ${esc(label[v.state] || 'en attente')}${v.at && v.state === 'ok' ? ' · ' + esc(ago(v.at)) : ''}</span>`;
  }).join('');
}
function renderGrid() {
  const g = $('#grid'), list = visibleOpps();
  if (ui.loading && !opps.length) { g.innerHTML = '<div class="skeleton"></div>'.repeat(4); return; }
  if (!list.length) { g.innerHTML = emptyOpps(); return; }
  const shown = list.slice(0, ui.limit);
  g.innerHTML = shown.map(cardHTML).join('') + (list.length > shown.length ? `<div class="empty" style="padding:14px"><button class="btn" data-act="more">Afficher plus (${list.length - shown.length} restantes)</button></div>` : '');
}
function renderCards() {
  renderLive(); renderBanner(); renderSrcs(); renderGrid();
  const vis = visibleOpps().filter(o => !decision(o.id)), best = vis.slice().sort((a, b) => b.gap - a.gap)[0];
  const enabled = enabledSources().length, ok = enabledSources().filter(k => ui.status[k] && ui.status[k].state === 'ok').length, st = trackStats();
  $('#kpis').innerHTML =
    kpiHTML('Opportunités', String(vis.length), `sur ${opps.length} analysées`) +
    kpiHTML('Plus gros écart', best ? pct(best.gap) : '—', best ? esc(best.title) : 'rien pour l’instant', best ? 'pos' : '') +
    kpiHTML('Sources', S.settings.demo ? '3/3' : `${ok}/${enabled}`, S.settings.demo ? 'démo' : ok === enabled ? 'toutes répondent' : 'certaines en erreur') +
    kpiHTML('Profit réalisé', money(st.realized), `${st.soldCount} vente${st.soldCount > 1 ? 's' : ''}`, st.realized > 0 ? 'pos' : st.realized < 0 ? 'neg' : '');
  $$('[data-act="dom"]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === ui.domain)));
}

/* ---------- Rendu : accueil ---------- */
function renderHome() {
  renderLive(); renderBanner();
  const vis = visibleOpps('all').filter(o => !decision(o.id)), st = trackStats(), bs = betStats();
  $('#hkpis').innerHTML =
    kpiHTML('Opportunités cartes et jeux', String(vis.length), `sur ${opps.length} analysées`) +
    kpiHTML('Meilleur écart crypto net', '—', 'en attente de données', '', 'k-net') +
    kpiHTML('Profit réalisé', money(st.realized), `${st.soldCount} vente${st.soldCount > 1 ? 's' : ''} · ${money(st.invested)} en stock`, st.realized > 0 ? 'pos' : st.realized < 0 ? 'neg' : '') +
    kpiHTML('Bilan paris', bs.settled ? (bs.net >= 0 ? '+' : '−') + money(Math.abs(bs.net)) : '—', bs.settled ? `${bs.settled} pari${bs.settled > 1 ? 's' : ''} réglé${bs.settled > 1 ? 's' : ''}` : 'aucun pari réglé', bs.net > 0 ? 'pos' : bs.net < 0 ? 'neg' : '');
  const top = vis.slice().sort((a, b) => b.score - a.score || b.gap - a.gap).slice(0, 5);
  $('#home-opps').innerHTML = top.length ? top.map(rowHTML).join('') : emptyOpps();
  buildCrypto('home-crypto', { coins: HOME_COINS, compact: true });
  renderRtStatus(); rtRender();
}

/* ---------- Rendu : cryptos ---------- */
function renderCrypto() {
  buildCrypto('crypto-table', { coins: COINS.map(c => c[0]), compact: false });
  const live = rtOn(), b = $('#btn-live');
  b.setAttribute('aria-pressed', String(live)); b.firstElementChild.textContent = live ? 'Pause' : 'Reprendre';
  renderRtStatus();
}

/* ---------- Rendu : paris ---------- */
function renderBets() {
  const bs = betStats();
  $('#bkpis').innerHTML =
    kpiHTML('Bilan net', bs.settled ? (bs.net >= 0 ? '+' : '−') + money(Math.abs(bs.net)) : '—', 'paris réglés', bs.net > 0 ? 'pos' : bs.net < 0 ? 'neg' : '') +
    kpiHTML('Rentabilité', bs.roi === null ? '—' : sp(bs.roi, 1), 'bilan sur mises réglées', bs.roi > 0 ? 'pos' : bs.roi < 0 ? 'neg' : '') +
    kpiHTML('Taux de réussite', bs.settled ? Math.round(bs.won / bs.settled * 100) + ' %' : '—', `${bs.won} gagné${bs.won > 1 ? 's' : ''} sur ${bs.settled}`) +
    kpiHTML('En cours', String(bs.pending), `pari${bs.pending > 1 ? 's' : ''} en attente`);
  $$('[data-act="btab"]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === ui.btab)));
  $('#btn-new-bet').hidden = ui.btab !== 'log' && false;
  const body = $('#bets-body'), cv = ui.calc;
  const v = k => esc(cv[k] ?? '');
  if (ui.btab === 'calc') {
    body.innerHTML = `<div class="bgrid">
      <section class="panel"><h2>Arbitrage (surebet)</h2><p class="muted small">Entre la meilleure cote décimale trouvée pour chaque issue, chez des bookmakers différents.</p>
        <div class="seg-inline"><button class="chip" data-act="sb-n" data-v="2" aria-pressed="${ui.sbN === 2}">2 issues</button><button class="chip" data-act="sb-n" data-v="3" aria-pressed="${ui.sbN === 3}">3 issues</button></div>
        <div class="fgrid">
          <label>Cote issue 1<input id="sb-o1" inputmode="decimal" autocomplete="off" placeholder="2,10" value="${v('sb-o1')}"></label>
          <label>Cote issue 2<input id="sb-o2" inputmode="decimal" autocomplete="off" placeholder="2,05" value="${v('sb-o2')}"></label>
          ${ui.sbN === 3 ? `<label>Cote issue 3<input id="sb-o3" inputmode="decimal" autocomplete="off" placeholder="3,40" value="${v('sb-o3')}"></label>` : ''}
          <label class="${ui.sbN === 3 ? '' : 'full'}">Mise totale (€)<input id="sb-stake" inputmode="decimal" autocomplete="off" value="${cv['sb-stake'] ?? '100'}"></label>
        </div><div id="sb-out" class="res" aria-live="polite"></div></section>
      <section class="panel"><h2>Valeur attendue</h2><p class="muted small">Compare ta probabilité estimée à celle que la cote suppose.</p>
        <div class="fgrid"><label>Cote décimale<input id="ev-odds" inputmode="decimal" autocomplete="off" placeholder="2,50" value="${v('ev-odds')}"></label><label>Ta probabilité (%)<input id="ev-p" inputmode="decimal" autocomplete="off" placeholder="45" value="${v('ev-p')}"></label></div>
        <div id="ev-out" class="res" aria-live="polite"></div></section></div>`;
    calcSure(); calcEv();
  } else if (ui.btab === 'scan') {
    const o = ui.odds;
    const sportSel = `<label class="full">Compétition<select data-set="sport">${SPORTS.map(([k, n]) => `<option value="${k}" ${k === S.settings.sport ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>`;
    let res = '';
    if (ui.oddsLoading) res = '<div class="res">Scan en cours…</div>';
    else if (ui.oddsErr) res = `<div class="banner err" role="alert">Scan impossible : ${esc(ui.oddsErr)}.</div>`;
    else if (o) {
      const sure = o.events.filter(e => e.inv < 1).length;
      res = `<div class="res"><div>${o.events.length} rencontre${o.events.length > 1 ? 's' : ''} analysée${o.events.length > 1 ? 's' : ''} ${esc(ago(o.at))}${o.demo ? ' (données fictives)' : ''}. <b class="${sure ? 'pos' : ''}">${sure} arbitrage${sure > 1 ? 's' : ''} détecté${sure > 1 ? 's' : ''}.</b></div>${o.remaining !== null ? `<div class="muted small">Crédits restants ce mois-ci : ${o.remaining}.</div>` : ''}</div><div class="evlist">` +
        o.events.slice(0, 40).map(e => {
          const lines = e.names.map(n => `<div>${esc(n)} : <b>${fmtOdd(e.best[n].price)}</b> chez ${esc(e.best[n].book)}${e.inv < 1 ? ` · miser ${money(100 * (1 / e.best[n].price) / e.inv)} sur 100 €` : ''}</div>`).join('');
          return `<div class="ev ${e.inv < 1 ? 'sure' : ''}"><div class="e-t">${esc(e.title)} ${e.inv < 1 ? '<span class="tag-live">Arbitrage</span>' : ''}</div><div class="e-o">${lines}</div><div class="${e.inv < 1 ? 'pos' : 'muted'} small">Marge : ${sp(e.margin)} (${e.nBooks} bookmakers comparés)</div></div>`;
        }).join('') + '</div>';
    }
    body.innerHTML = `<section class="panel"><h2>Scanner de cotes</h2><p class="muted small">Compare les cotes de plusieurs bookmakers via The Odds API. Chaque scan consomme des crédits : l’offre gratuite en donne 500 par mois, donc pas de temps réel. Il faut ta propre clé (Réglages).</p>
      <div class="fgrid">${sportSel}</div>
      <div style="margin-top:12px"><button class="btn primary" data-act="scan" ${ui.oddsLoading ? 'disabled' : ''}>Scanner maintenant</button></div>
      ${!oddsKey && !S.settings.demo ? '<p class="muted small" style="margin-top:10px">Aucune clé enregistrée : ajoute-la dans Réglages, section Paris.</p>' : ''}
      <p class="muted small" style="margin-top:10px">Des arbitrages réels sont rares et disparaissent vite. Les bookmakers peuvent limiter les comptes qui en profitent, et une cote périmée transforme un gain garanti en perte.</p>${res}</section>`;
  } else {
    const list = S.bets.slice().sort((a, b) => b.createdAt - a.createdAt);
    const rows = list.map(b => {
      const p = betProfit(b), lab = { pending: 'En cours', won: 'Gagné', lost: 'Perdu', void: 'Annulé' }[b.result];
      return `<article class="titem"><div class="t-top"><div><div class="t-name">${esc(b.label)}</div><div class="t-meta">Mise ${money(b.stake)} · cote ${fmtOdd(b.odds)} · ${lab}${b.date ? ' · ' + fmtDate(b.date) : ''}</div></div><div class="t-num ${p > 0 ? 'pos' : p < 0 ? 'neg' : ''}">${b.result === 'won' || b.result === 'lost' ? (p >= 0 ? '+' : '−') + money(Math.abs(p)) : ''}</div></div>${b.note ? `<div class="t-meta">${esc(b.note)}</div>` : ''}<div class="t-act"><button class="btn ghost" data-act="edit-bet" data-id="${esc(b.id)}">Modifier</button></div></article>`;
    }).join('');
    body.innerHTML = list.length ? `<div class="tlist">${rows}</div>` : '<div class="empty"><strong>Aucun pari enregistré</strong>Note tes paris pour voir, sans filtre, ce qu’ils te rapportent vraiment.</div>';
  }
}

/* ---------- Rendu : suivi ---------- */
const itemProfit = it => it.status === 'sold' && it.sell !== null && it.buy !== null ? (it.sell - it.buy) * it.qty - (it.fees || 0) : null;
function trackStats() {
  let invested = 0, realized = 0, soldCost = 0, soldCount = 0, days = 0, dn = 0;
  for (const it of S.tracker) {
    if (it.status === 'stock' && it.buy !== null) invested += it.buy * it.qty;
    if (it.status === 'sold') {
      const p = itemProfit(it);
      if (p !== null) { realized += p; soldCost += it.buy * it.qty; }
      soldCount++;
      if (it.buyDate && it.sellDate) { const dd = (new Date(it.sellDate) - new Date(it.buyDate)) / 864e5; if (dd >= 0) { days += dd; dn++; } }
    }
  }
  return { invested, realized, roi: soldCost > 0 ? realized / soldCost * 100 : null, soldCount, avgDays: dn ? days / dn : null, stockCount: S.tracker.filter(i => i.status === 'stock').length };
}
function renderTrack() {
  const st = trackStats();
  $('#tkpis').innerHTML =
    kpiHTML('Investi en stock', money(st.invested), `${st.stockCount} élément${st.stockCount > 1 ? 's' : ''}`) +
    kpiHTML('Profit réalisé', money(st.realized), `${st.soldCount} vente${st.soldCount > 1 ? 's' : ''}`, st.realized > 0 ? 'pos' : st.realized < 0 ? 'neg' : '') +
    kpiHTML('Rentabilité', st.roi === null ? '—' : (st.roi >= 0 ? '+' : '−') + Math.abs(st.roi).toFixed(0) + ' %', 'profit sur coût des ventes', st.roi > 0 ? 'pos' : st.roi < 0 ? 'neg' : '') +
    kpiHTML('Durée moyenne', st.avgDays === null ? '—' : Math.round(st.avgDays) + ' j', 'entre achat et vente');
  $$('[data-act="ttab"]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === ui.ttab)));
  const list = S.tracker.filter(i => i.status === ui.ttab).sort((a, b) => ui.ttab === 'sold' ? (b.sellDate || '').localeCompare(a.sellDate || '') : b.createdAt - a.createdAt);
  const el = $('#tlist');
  if (!list.length) {
    const msg = { stock: ['Rien en stock', 'Valide une opportunité en choisissant « Je l’ai acheté », ou ajoute un élément à la main.'], watch: ['Rien en surveillance', 'Valide une opportunité en choisissant « Je surveille seulement ».'], sold: ['Aucune vente enregistrée', 'Quand tu revends un élément du stock, marque-le comme vendu pour voir ton profit.'] }[ui.ttab];
    el.innerHTML = `<div class="empty"><strong>${msg[0]}</strong>${msg[1]}</div>`;
    return;
  }
  el.innerHTML = list.map(it => {
    const p = itemProfit(it);
    const right = it.status === 'sold' ? (p === null ? '' : `<span class="${p >= 0 ? 'pos' : 'neg'}">${p >= 0 ? '+' : '−'}${money(Math.abs(p))}</span>`) : (it.buy !== null ? money(it.buy * it.qty) : '');
    const meta = [DOMAINS[it.domain], it.qty > 1 ? `${it.qty} × ${it.buy !== null ? money(it.buy) : '?'}` : (it.buy !== null ? money(it.buy) : ''), it.status === 'sold' && it.sell !== null ? `vendu ${money(it.sell)}${it.qty > 1 ? ' l’unité' : ''}` : '', it.status === 'sold' ? fmtDate(it.sellDate) : fmtDate(it.buyDate)].filter(Boolean).join(' · ');
    const act = it.status === 'stock' ? `<button class="btn" data-act="mark-sold" data-id="${esc(it.id)}">Marquer vendu</button>` : it.status === 'watch' ? `<button class="btn" data-act="mark-bought" data-id="${esc(it.id)}">Je l’ai acheté</button>` : '';
    return `<article class="titem"><div class="t-top"><div><div class="t-name">${esc(it.name)}</div><div class="t-meta">${esc(meta)}</div></div><div class="t-num">${right}</div></div>${it.note ? `<div class="t-meta">${esc(it.note)}</div>` : ''}<div class="t-act">${act}${it.url ? `<a class="btn ghost" href="${esc(it.url)}" target="_blank" rel="noopener noreferrer">Voir</a>` : ''}<button class="btn ghost" data-act="edit-item" data-id="${esc(it.id)}">Modifier</button></div></article>`;
  }).join('');
}
function calcMargin() {
  const buy = num($('#c-buy').value, 0, 1e7, null), sell = num($('#c-sell').value, 0, 1e7, null), fee = num($('#c-fee').value, 0, 90, 10), ship = num($('#c-ship').value, 0, 1e5, 0), out = $('#c-out');
  if (buy === null || sell === null) { out.textContent = 'Renseigne l’achat et la revente.'; out.className = 'calc-out'; return; }
  const net = sell * (1 - fee / 100) - ship - buy, roi = buy > 0 ? net / buy * 100 : 0, be = (buy + ship) / (1 - fee / 100);
  out.className = 'calc-out ' + (net >= 0 ? 'pos' : 'neg');
  out.textContent = `Gain net : ${net >= 0 ? '+' : '−'}${money(Math.abs(net))} (${roi >= 0 ? '+' : '−'}${Math.abs(roi).toFixed(0)} %). Seuil de rentabilité : revendre à ${money(be)}.`;
}

/* ---------- Rendu : réglages ---------- */
const getPath = (o, p) => p.split('.').reduce((a, k) => a && a[k], o);
function setPath(o, p, v) { const ks = p.split('.'); let t = o; while (ks.length > 1) t = t[ks.shift()]; t[ks[0]] = v; }
function sw(path, label, desc) {
  const on = !!getPath(S.settings, path);
  return `<div class="row"><div><div class="r-t">${label}</div>${desc ? `<div class="r-d">${desc}</div>` : ''}</div><div class="switch-wrap"><button type="button" class="switch" role="switch" aria-checked="${on}" aria-label="${label}" data-act="toggle" data-p="${path}"></button></div></div>`;
}
function renderSettings() {
  const s = S.settings;
  const nf = (path, label, hint) => `<label>${label}<input inputmode="decimal" autocomplete="off" data-set="${path}" value="${esc(String(getPath(s, path)).replace('.', ','))}">${hint ? `<span class="r-d">${hint}</span>` : ''}</label>`;
  $('#settings-body').innerHTML = `
  <section class="panel"><h2>Cartes et jeux</h2><div class="sgroup">
    ${sw('src.pokemon', 'Cartes Pokémon', 'Cardmarket et TCGplayer via pokemontcg.io')}
    ${sw('src.magic', 'Cartes Magic', 'Prix EUR et USD via Scryfall')}
    ${sw('src.games', 'Jeux PC', 'Promotions via CheapShark')}
    ${sw('auto', 'Actualisation automatique', 'Seulement quand l’app est ouverte')}
    <div class="row"><div><div class="r-t">Fréquence</div><div class="r-d">Plus court = plus d’appels (quotas gratuits)</div></div>
      <select data-set="interval" aria-label="Fréquence d’actualisation" style="width:auto;min-width:110px">${[2, 5, 10, 30].map(n => `<option value="${n}" ${n === s.interval ? 'selected' : ''}>${n} min</option>`).join('')}</select></div>
    ${sw('demo', 'Mode démo', 'Données fictives (cartes, jeux, cryptos, cotes), aucun appel réseau')}
  </div></section>

  <section class="panel"><h2>Cryptos en temps réel</h2><div class="sgroup">
    ${sw('crypto.live', 'Flux en direct', 'Connexion WebSocket tant que l’écran Accueil ou Cryptos est ouvert')}
    ${sw('crypto.ex.binance', 'Binance', 'Paires en euros')}
    ${sw('crypto.ex.coinbase', 'Coinbase', 'Paires en euros')}
    ${sw('crypto.ex.kraken', 'Kraken', 'Paires en euros')}
  </div>
  <div class="fgrid" style="margin-top:10px">
    ${nf('crypto.fees.binance', 'Frais Binance (%)', 'Frais taker par ordre')}
    ${nf('crypto.fees.coinbase', 'Frais Coinbase (%)', 'À adapter à ton palier')}
    ${nf('crypto.fees.kraken', 'Frais Kraken (%)', 'Utilisés pour l’écart net')}
  </div></section>

  <section class="panel"><h2>Seuils d’affichage</h2><div class="fgrid">
    ${nf('minGap', 'Écart minimum (%)', 'Entre 5 et 90')}
    ${nf('minScore', 'Score minimum', 'De 0 à 100')}
    ${nf('minRef', 'Cartes : prix mini (€)', 'Prix de référence')}
    ${nf('maxRef', 'Cartes : prix maxi (€)', 'Tranche analysée')}
    ${nf('maxGamePrice', 'Jeux PC : prix maxi ($)', 'Promotions affichées')}
  </div></section>

  <section class="panel"><h2>Clés et adresses d’API</h2>
    <p class="muted small">Les clés restent sur cet appareil et ne sont jamais incluses dans la sauvegarde.</p>
    <label style="margin-top:10px">Clé pokemontcg.io (facultative : 20 000 appels par jour au lieu de 1 000)
      <input type="password" id="apikey" autocomplete="off" autocapitalize="off" spellcheck="false" value="${esc(apiKey)}" placeholder="Colle ta clé ici"></label>
    <label style="margin-top:10px">Paris : clé The Odds API (facultative, 500 crédits par mois gratuits)
      <input type="password" id="oddskey" autocomplete="off" autocapitalize="off" spellcheck="false" value="${esc(oddsKey)}" placeholder="Colle ta clé ici"></label>
    <details class="adv"><summary>Adresses des API (avancé)</summary>
      <p class="muted small">À modifier seulement si une source bloque les appels depuis le navigateur (CORS) ou change d’adresse.</p>
      <div class="fgrid" style="margin-top:10px">
        ${Object.keys(DEFAULT_URLS).map(k => `<label class="full">${URL_LABEL[k]}<input data-set="urls.${k}" autocomplete="off" autocapitalize="off" spellcheck="false" value="${esc(s.urls[k])}"></label>`).join('')}
      </div>
      <div style="margin-top:10px"><button class="btn" data-act="reset-urls">Remettre les adresses d’origine</button></div>
    </details></section>

  <section class="panel"><h2>Sauvegarde</h2>
    <p class="muted small">Tes données restent sur cet appareil. Exporte-les pour les garder ou les passer d’un appareil à l’autre.</p>
    <div class="btn-row" style="margin-top:12px">
      <button class="btn" data-act="export">Exporter (JSON)</button>
      <button class="btn" data-act="import">Importer</button>
      <button class="btn danger" data-act="wipe">Tout effacer</button>
    </div>
    <p class="muted small" style="margin-top:12px">Stockage persistant : ${ui.persist === true ? 'accordé' : ui.persist === false ? 'non accordé (le navigateur peut vider les données si l’espace manque)' : 'inconnu'}.</p>
  </section>

  <section class="panel wide"><h2>Sources, calculs et limites</h2>
    <div class="srcrow"><div class="s-h"><span class="badge dom-crypto">Cryptos</span>Binance, Coinbase, Kraken</div><p>Flux WebSocket publics, sans clé, en euros. L’écart net = (meilleur prix de vente − meilleur prix d’achat entre deux bourses différentes) moins les frais que tu règles ci-dessus. Il ignore retraits, délais, profondeur du carnet et impôt : à lire comme une donnée, jamais comme un conseil. L’app ne passe aucun ordre.</p></div>
    <div class="srcrow"><div class="s-h"><span class="badge dom-pokemon">Pokémon</span>pokemontcg.io</div><p>Analyse les 250 cartes les plus chères de ta tranche de prix. Écart = (tendance Cardmarket − prix bas) / tendance. Score = 2,2 × écart, +10 si le prix bas passe sous 90 % de la moyenne 30 jours, jusqu’à +15 si TCGplayer (converti en euros) est nettement plus cher. Prix mis à jour par intervalles, pas en continu.</p></div>
    <div class="srcrow"><div class="s-h"><span class="badge dom-magic">Magic</span>Scryfall</div><p>Compare le prix en euros et en dollars convertis, une fois par jour. Signal faible (frais, port et taxes ignorés) : score plafonné à 70.</p></div>
    <div class="srcrow"><div class="s-h"><span class="badge dom-games">Jeux PC</span>CheapShark</div><p>Promotions de plus de 30 boutiques. Score = 0,5 × remise + 3 × note de l’offre (sur 10) + 20 si le prix égale le plus bas connu. Pour acheter pour toi : la revente de clés est souvent interdite.</p></div>
    <div class="srcrow"><div class="s-h"><span class="badge dom-other">Paris</span>The Odds API (optionnel)</div><p>Aucun gagnant n’est prédit. Le scanner compare les meilleures cotes entre bookmakers et signale un arbitrage seulement si la somme des probabilités implicites est inférieure à 100 %.</p></div>
    <div class="srcrow"><div class="s-h"><span class="badge dom-other">Labo</span>Backtest et simulateur</div><p>Le backtest rejoue l’historique public Binance sur 20 cryptos : réglages choisis sur les 70 % anciens, vérifiés sur les 30 % récents jamais vus, comparés à « garder ». Le simulateur memecoins « achète » de nouveaux tokens Solana (DexScreener) avec frais, slippage et rugs. Tout est fictif : aucun ordre, aucune clé de portefeuille. Le mode démo génère des données fictives.</p></div>
    <p class="muted small" style="margin-top:10px"><b>Pas couvert :</b></p>
    <ul class="plain">
      <li>Vinted et Leboncoin : pas d’API publique, et leur collecte automatique est contraire à leurs conditions.</li>
      <li>eBay : accès en production soumis à l’approbation d’eBay. Cardmarket (API) : fermée aux nouvelles demandes.</li>
      <li>Cotes sportives en temps réel : les quotas gratuits sont trop faibles.</li>
    </ul>
    <p class="muted small" style="margin-top:10px">Un écart de prix n’est pas un gain garanti : frais, port, état de l’objet et délai de revente comptent. L’app ne passe aucune commande à ta place.</p>
  </section>`;
}

/* ---------- Feuilles modales ---------- */
const sheet = $('#sheet');
function openSheet(html) { sheet.innerHTML = html; if (!sheet.open) sheet.showModal(); }
function closeSheet() { if (sheet.open) sheet.close(); }
sheet.addEventListener('click', e => { if (e.target === sheet) closeSheet(); });
sheet.addEventListener('close', () => { sheet.innerHTML = ''; $$('.card.settle').forEach(c => { c.style.transform = ''; c.style.opacity = ''; c.classList.remove('settle'); }); });

function openValidate(id) {
  const o = opps.find(x => x.id === id);
  if (!o) { $$('.card.settle').forEach(c => { c.style.transform = ''; c.style.opacity = ''; c.classList.remove('settle'); }); return; }
  const fxr = (cache.fx && cache.fx.rate) || 0.92, eur = o.cur === 'USD' ? o.price * fxr : o.price;
  openSheet(`<form class="sheet" data-form="validate" data-id="${esc(id)}">
    <h2 id="sheet-title">Valider cette opportunité</h2>
    <p class="muted small">${esc(o.title)}${o.sub ? ' · ' + esc(o.sub) : ''}</p>
    <div class="seg" role="radiogroup" aria-label="Que veux-tu faire ?">
      <label><input type="radio" name="mode" value="stock" checked><span>Je l’ai acheté</span></label>
      <label><input type="radio" name="mode" value="watch"><span>Je surveille seulement</span></label>
    </div>
    <div class="fgrid">
      <label>Prix payé par unité (€)<input name="buy" inputmode="decimal" autocomplete="off" value="${esc(eur.toFixed(2).replace('.', ','))}"></label>
      <label>Quantité<input name="qty" inputmode="numeric" autocomplete="off" value="1"></label>
    </div>
    ${o.cur === 'USD' ? '<p class="muted small">Prix converti en euros au taux du jour : corrige-le si tu as payé autre chose.</p>' : ''}
    <div class="s-actions"><button type="button" class="btn" data-act="close">Annuler</button><button class="btn primary">Enregistrer</button></div>
  </form>`);
}
function itemForm(it, title) {
  const sold = it.status === 'sold', n = v => v === null || v === undefined ? '' : String(v).replace('.', ',');
  return `<form class="sheet" data-form="item" data-id="${esc(it.id || '')}">
    <h2 id="sheet-title">${title}</h2>
    <label>Nom<input name="name" required maxlength="120" autocomplete="off" value="${esc(it.name)}"></label>
    <div class="fgrid">
      <label>Domaine<select name="domain">${Object.entries(DOMAINS).map(([k, v]) => `<option value="${k}" ${k === it.domain ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label>État<select name="status"><option value="watch" ${it.status === 'watch' ? 'selected' : ''}>Surveillé</option><option value="stock" ${it.status === 'stock' ? 'selected' : ''}>En stock</option><option value="sold" ${sold ? 'selected' : ''}>Vendu</option></select></label>
      <label>Prix d’achat par unité (€)<input name="buy" inputmode="decimal" autocomplete="off" value="${esc(n(it.buy))}"></label>
      <label>Quantité<input name="qty" inputmode="numeric" autocomplete="off" value="${esc(it.qty)}"></label>
      <label>Date d’achat<input type="date" name="buyDate" value="${esc(it.buyDate)}"></label>
      <label class="sold-only" ${sold ? '' : 'hidden'}>Prix de vente par unité (€)<input name="sell" inputmode="decimal" autocomplete="off" value="${esc(n(it.sell))}"></label>
      <label class="sold-only" ${sold ? '' : 'hidden'}>Frais et port au total (€)<input name="fees" inputmode="decimal" autocomplete="off" value="${esc(n(it.fees))}"></label>
      <label class="sold-only" ${sold ? '' : 'hidden'}>Date de vente<input type="date" name="sellDate" value="${esc(it.sellDate)}"></label>
      <label class="full">Note<textarea name="note" maxlength="300">${esc(it.note)}</textarea></label>
    </div>
    <div class="s-actions">${it.id ? '<button type="button" class="btn danger" data-act="del-item">Supprimer</button>' : '<button type="button" class="btn" data-act="close">Annuler</button>'}<button class="btn primary">Enregistrer</button></div>
    ${it.id ? '<div class="s-actions" style="margin-top:-4px"><button type="button" class="btn ghost" data-act="close">Fermer sans enregistrer</button></div>' : ''}
  </form>`;
}
const blankItem = (o = {}) => ({ id: '', name: '', domain: 'other', status: 'stock', buy: null, qty: 1, sell: null, fees: 0, buyDate: today(), sellDate: '', note: '', url: '', ...o });
function betForm(b, title) {
  return `<form class="sheet" data-form="bet" data-id="${esc(b.id || '')}">
    <h2 id="sheet-title">${title}</h2>
    <label>Pari (rencontre et issue)<input name="label" required maxlength="120" autocomplete="off" value="${esc(b.label)}"></label>
    <div class="fgrid">
      <label>Mise (€)<input name="stake" inputmode="decimal" autocomplete="off" value="${esc(String(b.stake ?? '').replace('.', ','))}"></label>
      <label>Cote décimale<input name="odds" inputmode="decimal" autocomplete="off" value="${esc(String(b.odds ?? '').replace('.', ','))}"></label>
      <label>Résultat<select name="result">${[['pending', 'En cours'], ['won', 'Gagné'], ['lost', 'Perdu'], ['void', 'Annulé']].map(([k, v]) => `<option value="${k}" ${k === b.result ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label>Date<input type="date" name="date" value="${esc(b.date)}"></label>
      <label class="full">Note<textarea name="note" maxlength="300">${esc(b.note)}</textarea></label>
    </div>
    <div class="s-actions">${b.id ? '<button type="button" class="btn danger" data-act="del-bet">Supprimer</button>' : '<button type="button" class="btn" data-act="close">Annuler</button>'}<button class="btn primary">Enregistrer</button></div>
  </form>`;
}
const blankBet = () => ({ id: '', label: '', stake: '', odds: '', result: 'pending', date: today(), note: '' });
function openConfirm(title, text, action, label = 'Confirmer', danger = false) {
  openSheet(`<form class="sheet" data-form="confirm" data-action="${esc(action)}"><h2 id="sheet-title">${esc(title)}</h2><p class="muted">${esc(text)}</p><div class="s-actions"><button type="button" class="btn" data-act="close">Annuler</button><button class="btn ${danger ? 'danger' : 'primary'}">${esc(label)}</button></div></form>`);
}
let pendingImport = null, pendingLab = null;

document.addEventListener('submit', e => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  const fd = new FormData(f), kind = f.dataset.form;
  if (kind === 'validate') {
    const o = opps.find(x => x.id === f.dataset.id);
    if (!o) return closeSheet();
    const mode = fd.get('mode') === 'watch' ? 'watch' : 'stock';
    S.tracker.unshift(cleanTracker([{ id: uid(), name: o.title, domain: o.domain, status: mode, buy: num(String(fd.get('buy')), 0, 1e7, null), qty: num(String(fd.get('qty')), 1, 9999, 1), buyDate: mode === 'stock' ? today() : '', note: o.sub, url: o.url, createdAt: Date.now() }])[0]);
    decide(o.id, 'ok'); save(); closeSheet(); renderData();
    toast(mode === 'stock' ? 'Ajouté à ton stock.' : 'Ajouté à ta surveillance.');
  } else if (kind === 'item') {
    const id = f.dataset.id, prev = S.tracker.find(i => i.id === id);
    const status = ['watch', 'stock', 'sold'].includes(fd.get('status')) ? fd.get('status') : 'watch';
    const it = cleanTracker([{
      id: id || uid(), name: fd.get('name'), domain: fd.get('domain'), status,
      buy: String(fd.get('buy')).trim() === '' ? null : num(String(fd.get('buy')), 0, 1e7, null), qty: num(String(fd.get('qty')), 1, 9999, 1),
      sell: status === 'sold' && String(fd.get('sell')).trim() !== '' ? num(String(fd.get('sell')), 0, 1e7, null) : null,
      fees: status === 'sold' ? num(String(fd.get('fees')), 0, 1e7, 0) : 0,
      buyDate: fd.get('buyDate') || (status !== 'watch' ? today() : ''), sellDate: status === 'sold' ? (fd.get('sellDate') || today()) : '',
      note: fd.get('note'), url: prev ? prev.url : '', createdAt: prev ? prev.createdAt : Date.now(),
    }])[0];
    if (!it) { toast('Le nom est obligatoire.'); return; }
    if (prev) S.tracker[S.tracker.indexOf(prev)] = it; else S.tracker.unshift(it);
    ui.ttab = it.status; save(); closeSheet(); renderData(); toast('Enregistré.');
  } else if (kind === 'bet') {
    const id = f.dataset.id, prev = S.bets.find(b => b.id === id);
    const b = cleanBets([{ id: id || uid(), label: fd.get('label'), stake: num(String(fd.get('stake')), 0, 1e6, null), odds: num(String(fd.get('odds')), 1.01, 1000, null), result: fd.get('result'), date: fd.get('date'), note: fd.get('note'), createdAt: prev ? prev.createdAt : Date.now() }])[0];
    if (!b) { toast('Renseigne le pari, une mise et une cote supérieure à 1.'); return; }
    if (prev) S.bets[S.bets.indexOf(prev)] = b; else S.bets.unshift(b);
    ui.btab = 'log'; save(); closeSheet(); renderData(); toast('Pari enregistré.');
  } else if (kind === 'confirm') {
    const a = f.dataset.action;
    if (a === 'wipe') wipeAll();
    if (a === 'lab-reset' && window.Lab) { Lab.resetSim(); closeSheet(); toast('Simulateur remis à zéro.'); }
    if (a === 'import' && pendingImport) { S = pendingImport; pendingImport = null; if (window.Lab && pendingLab) Lab.apply(pendingLab); pendingLab = null; save(); closeSheet(); afterDataReplace(); toast('Sauvegarde importée.'); }
  }
});
document.addEventListener('change', e => {
  const sel = e.target.closest('form[data-form="item"] select[name="status"]');
  if (sel) sel.closest('form').querySelectorAll('.sold-only').forEach(l => { l.hidden = sel.value !== 'sold'; });
});

/* ---------- Export / import / effacement ---------- */
async function doExport() {
  flush();
  const payload = { app: APP, version: 2, exportedAt: new Date().toISOString(), data: { onboarded: true, settings: S.settings, tracker: S.tracker, bets: S.bets, decisions: S.decisions, lab: window.Lab ? Lab.snapshot() : null } };
  const name = `denicheur-sauvegarde-${today()}.json`;
  const file = new File([JSON.stringify(payload, null, 2)], name, { type: 'application/json' });
  try { if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file] }); return; } }
  catch (e) { if (e && e.name === 'AbortError') return; }
  const url = URL.createObjectURL(file), a = document.createElement('a');
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  toast('Sauvegarde téléchargée.');
}
async function handleImportFile(file) {
  if (!file) return;
  if (file.size > 2e6) return toast('Fichier trop volumineux (2 Mo maximum).');
  let j;
  try { j = JSON.parse(await file.text()); } catch { return toast('Fichier illisible : ce n’est pas un JSON valide.'); }
  if (!j || j.app !== APP || !j.data || typeof j.data !== 'object') return toast('Ce fichier n’est pas une sauvegarde Dénicheur.');
  pendingImport = fromData({ ...j.data, onboarded: true }); pendingLab = window.Lab ? Lab.clean(j.data.lab) : null;
  const n = pendingImport.tracker.length, b = pendingImport.bets.length;
  openConfirm('Importer cette sauvegarde ?', `${n} élément${n > 1 ? 's' : ''} de suivi, ${b} pari${b > 1 ? 's' : ''} et tes réglages. Cela remplace les données actuelles de cet appareil.`, 'import', 'Importer');
}
function wipeAll() {
  try { [LS_MAIN, LS_KEY, LS_ODDS, LS_CACHE].forEach(k => localStorage.removeItem(k)); } catch { /* ignoré */ }
  clearTimeout(saveTimer); saveTimer = 0;
  rtStop(); if (window.Lab) Lab.wipe();
  S = fromData(null); apiKey = ''; oddsKey = ''; cache = {}; opps = []; ui.status = {}; ui.domain = 'all'; ui.q = ''; ui.view = 'home'; ui.odds = null; ui.calc = {};
  RT.tick = {}; RT.hist = {}; RT.regs = {};
  $('#q').value = '';
  closeSheet(); render(); toast('Toutes les données ont été effacées.');
}
function afterDataReplace() { rebuildOpps(); RT.tick = {}; RT.hist = {}; render(); if (S.onboarded) refreshAll(); }

/* ---------- Navigation et rendu global ---------- */
function renderData() {
  ({ home: renderHome, cards: renderCards, crypto: renderCrypto, bets: renderBets, lab: () => {}, track: renderTrack, settings: () => {} })[ui.view]();
}
function render() {
  $('#app').dataset.state = S.onboarded ? 'main' : 'welcome';
  $('#view-welcome').hidden = S.onboarded;
  for (const v of VIEWS) $('#view-' + v).hidden = !S.onboarded || ui.view !== v;
  $$('[data-act="view"]').forEach(b => { if (b.dataset.v === ui.view) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  if (S.onboarded) ({ home: renderHome, cards: renderCards, crypto: renderCrypto, bets: renderBets, lab: () => { if (window.Lab) Lab.render(); }, track: renderTrack, settings: renderSettings })[ui.view]();
  rtSync(); if (window.Lab) Lab.sync();
}
function setView(v) {
  if (!VIEWS.includes(v)) return;
  ui.view = v; render(); scrollTo(0, 0);
  if (v === 'settings') askPersist().then(() => { if (ui.view === 'settings') renderSettings(); });
}

/* ---------- Notifications ---------- */
let toastTimer = 0, toastFn = null;
function toast(msg, action, fn) {
  const t = $('#toast');
  toastFn = fn || null;
  t.innerHTML = `<span>${esc(msg)}</span>${action ? `<button type="button" data-act="toast-action">${esc(action)}</button>` : ''}`;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; toastFn = null; }, action ? 6500 : 3200);
}

/* ---------- Actions (délégation d'événements) ---------- */
function ignoreOpp(id) { decide(id, 'no'); renderData(); toast('Opportunité ignorée.', 'Annuler', () => { decide(id, null); renderData(); }); }
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act, id = el.dataset.id;
  switch (a) {
    case 'view': setView(el.dataset.v); break;
    case 'start': S.onboarded = true; save(); askPersist(); ui.view = 'home'; render(); refreshAll(); break;
    case 'start-demo': S.onboarded = true; S.settings.demo = true; save(); ui.view = 'home'; rebuildOpps(); render(); refreshAll(); break;
    case 'refresh': refreshAll(); break;
    case 'dom': ui.domain = el.dataset.v; ui.limit = 60; renderCards(); break;
    case 'more': ui.limit += 60; renderGrid(); break;
    case 'ignore': ignoreOpp(id); break;
    case 'validate': openValidate(id); break;
    case 'undo-decision': decide(id, null); renderData(); break;
    case 'close': closeSheet(); break;
    case 'ttab': ui.ttab = el.dataset.v; renderTrack(); break;
    case 'btab': ui.btab = el.dataset.v; renderBets(); break;
    case 'sb-n': ui.sbN = Number(el.dataset.v) === 3 ? 3 : 2; renderBets(); break;
    case 'scan': scanOdds(); break;
    case 'toggle-live': S.settings.crypto.live = !S.settings.crypto.live; save(); rtRestart(); renderCrypto(); break;
    case 'new-item': openSheet(itemForm(blankItem(), 'Ajouter un élément')); break;
    case 'new-bet': openSheet(betForm(blankBet(), 'Ajouter un pari')); break;
    case 'edit-item': { const it = S.tracker.find(i => i.id === id); if (it) openSheet(itemForm(it, 'Modifier')); break; }
    case 'edit-bet': { const b = S.bets.find(i => i.id === id); if (b) openSheet(betForm(b, 'Modifier le pari')); break; }
    case 'mark-sold': { const it = S.tracker.find(i => i.id === id); if (it) openSheet(itemForm({ ...it, status: 'sold', sellDate: today() }, 'Marquer comme vendu')); break; }
    case 'mark-bought': { const it = S.tracker.find(i => i.id === id); if (it) openSheet(itemForm({ ...it, status: 'stock', buyDate: today() }, 'Marquer comme acheté')); break; }
    case 'del-item': { const f = el.closest('form'), it = S.tracker.find(i => i.id === f.dataset.id); if (it) { S.tracker = S.tracker.filter(i => i !== it); save(); closeSheet(); renderData(); toast('Supprimé.', 'Annuler', () => { S.tracker.unshift(it); save(); renderData(); }); } break; }
    case 'del-bet': { const f = el.closest('form'), b = S.bets.find(i => i.id === f.dataset.id); if (b) { S.bets = S.bets.filter(i => i !== b); save(); closeSheet(); renderData(); toast('Supprimé.', 'Annuler', () => { S.bets.unshift(b); save(); renderData(); }); } break; }
    case 'toggle': {
      const p = el.dataset.p, s = JSON.parse(JSON.stringify(S.settings));
      setPath(s, p, !getPath(s, p)); S.settings = cleanSettings(s); scheduleSave();
      el.setAttribute('aria-checked', String(!!getPath(S.settings, p)));
      if (p === 'demo') { rtRestart(); scheduleRefresh(); }
      else if (p.startsWith('src.')) scheduleRefresh();
      else if (p.startsWith('crypto.')) rtRestart();
      else renderLive();
      break;
    }
    case 'reset-urls': { const s = JSON.parse(JSON.stringify(S.settings)); s.urls = { ...DEFAULT_URLS }; S.settings = cleanSettings(s); scheduleSave(); renderSettings(); rtRestart(); scheduleRefresh(); toast('Adresses d’origine rétablies.'); break; }
    case 'export': doExport(); break;
    case 'import': $('#file').click(); break;
    case 'wipe': openConfirm('Tout effacer ?', 'Suivi, paris, réglages, clés d’API et décisions seront supprimés de cet appareil. Pense à exporter une sauvegarde avant.', 'wipe', 'Tout effacer', true); break;
    case 'toast-action': if (toastFn) toastFn(); $('#toast').hidden = true; toastFn = null; break;
  }
});
document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'q') { ui.q = t.value; ui.limit = 60; renderGrid(); }
  else if (t.id && t.id.startsWith('c-')) calcMargin();
  else if (t.id && (t.id.startsWith('sb-') || t.id.startsWith('ev-'))) { ui.calc[t.id] = t.value; t.id.startsWith('sb-') ? calcSure() : calcEv(); }
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.id === 'sort') { ui.sort = t.value; renderGrid(); }
  else if (t.id === 'showTreated') { ui.treated = t.checked; ui.limit = 60; renderCards(); }
  else if (t.id === 'file') { handleImportFile(t.files[0]); t.value = ''; }
  else if (t.id === 'apikey') { apiKey = str(t.value, 80); try { localStorage.setItem(LS_KEY, apiKey); } catch { /* ignoré */ } scheduleRefresh(); }
  else if (t.id === 'oddskey') { oddsKey = str(t.value, 80); try { localStorage.setItem(LS_ODDS, oddsKey); } catch { /* ignoré */ } }
  else if (t.dataset && t.dataset.set) {
    const p = t.dataset.set, s = JSON.parse(JSON.stringify(S.settings));
    setPath(s, p, p === 'interval' ? Number(t.value) : t.value);
    S.settings = cleanSettings(s); scheduleSave();
    const cur = getPath(S.settings, p);
    t.value = typeof cur === 'number' ? String(cur).replace('.', ',') : String(cur);
    renderLive();
    if (p.startsWith('crypto.fees')) rtRender();
    else if (p.startsWith('urls.ws')) rtRestart();
    else if (p.startsWith('urls.')) scheduleRefresh();
    else if (p === 'minGap' || p === 'minScore') renderData();
    else if (p !== 'interval' && p !== 'sport') scheduleRefresh();
  }
});
document.addEventListener('error', e => { const t = e.target; if (t && t.tagName === 'IMG') { const th = t.closest('.thumb'); if (th) th.classList.add('noimg'); } }, true);

/* Balayage tactile : droite = valider, gauche = ignorer */
let drag = null;
const gridEl = $('#grid');
gridEl.addEventListener('pointerdown', e => {
  if (e.pointerType === 'mouse') return;
  const card = e.target.closest('.card');
  if (!card || card.classList.contains('treated') || e.target.closest('a,button')) return;
  drag = { card, x: e.clientX, y: e.clientY, id: e.pointerId, active: false, dx: 0 };
});
gridEl.addEventListener('pointermove', e => {
  if (!drag || e.pointerId !== drag.id) return;
  const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
  if (!drag.active) {
    if (Math.abs(dx) > 14 && Math.abs(dx) > Math.abs(dy) * 1.6) { drag.active = true; drag.card.classList.add('dragging'); try { drag.card.setPointerCapture(e.pointerId); } catch { /* ignoré */ } }
    else if (Math.abs(dy) > 14) { drag = null; return; }
  }
  if (drag && drag.active) { drag.dx = dx; drag.card.style.transform = `translateX(${dx}px)`; drag.card.style.opacity = String(1 - Math.min(.5, Math.abs(dx) / 380)); }
});
const endDrag = e => {
  if (!drag || e.pointerId !== drag.id) return;
  const d = drag; drag = null;
  if (!d.active) return;
  d.card.classList.remove('dragging'); d.card.classList.add('settle');
  const id = d.card.dataset.id;
  if (d.dx > 110) openValidate(id);
  else if (d.dx < -110) { d.card.style.transform = 'translateX(-110%)'; d.card.style.opacity = '0'; setTimeout(() => ignoreOpp(id), 160); return; }
  if (d.dx <= 110) { d.card.style.transform = ''; d.card.style.opacity = ''; }
};
gridEl.addEventListener('pointerup', endDrag);
gridEl.addEventListener('pointercancel', endDrag);

/* Clavier : 1 à 6 écrans, N ajouter, R actualiser, / rechercher */
document.addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey || sheet.open) return;
  const t = e.target;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) { if (e.key === 'Escape' && t.id === 'q') { t.value = ''; ui.q = ''; renderGrid(); t.blur(); } return; }
  if (!S.onboarded) return;
  const k = e.key.toLowerCase();
  if (k === 'n') { e.preventDefault(); if (ui.view === 'bets') openSheet(betForm(blankBet(), 'Ajouter un pari')); else openSheet(itemForm(blankItem(), 'Ajouter un élément')); }
  else if (k === 'r') { e.preventDefault(); refreshAll(); }
  else if (k === '/') { e.preventDefault(); setView('cards'); $('#q').focus(); }
  else if ('1234567'.includes(k) && k) setView(VIEWS[Number(k) - 1]);
});
addEventListener('online', () => { renderBanner(); if (S.onboarded) { refreshAll(); if (RT.running) rtRestart(); } });
addEventListener('offline', () => { renderBanner(); });

/* ---------- Démarrage ---------- */
render();
if (S.onboarded) {
  rebuildOpps();
  for (const k of Object.keys(SRC_LABEL)) ui.status[k] = S.settings.demo ? { state: 'demo' } : (cache[k] && S.settings.src[k] ? { state: 'ok', at: cache[k].at } : { state: S.settings.src[k] ? 'idle' : 'off' });
  renderData();
  if (S.settings.demo || !lastUpdate() || Date.now() - lastUpdate() > S.settings.interval * 60000) refreshAll();
}
if ('serviceWorker' in navigator) {
  addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').then(reg => {
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        if (w) w.addEventListener('statechange', () => { if (w.state === 'installed' && navigator.serviceWorker.controller) toast('Nouvelle version prête.', 'Recharger', () => location.reload()); });
      });
    }).catch(() => { /* l'app fonctionne sans service worker */ });
  });
}
